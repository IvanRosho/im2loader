﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Windows.Forms;

namespace IPOF_Converter
{
    partial class About : Form
    {
        Form1 form;
        public About(Form1 f)
        {
            InitializeComponent();
            form = f;
            this.Text = "Converter: tiff to im2 & xml";
            this.labelProductName.Text = "Converter: tiff to im2 i xml";
            this.labelVersion.Text = "Версия 1.1";
            this.labelCopyright.Text = "Copyright © ПАО КМЗ 2019";
            this.labelCompanyName.Text = "ПАО КМЗ имени С.А. Зверева";
            //        this.textBoxDescription.Text = Properties.Resources.Description;
            this.textBoxDescription.Text = "Описание: \r\n \r\n" +
            "Специализированное програмное обеспечение подготовки и \r\n" +
            "обработки файлов, содержащих видеоданные и служебную \r\n" +
            "информацию от датчиков автоколлимационных служебных \r\n" +
            "систем оптико - электронного комплекса дистанционного \r\n" +
            "зондирования Земли(ДЗЗ). \r\n \r\n" +
            "Version 1.1: \r\n" +
            "Добавлена конвертация файлов формата tiff.";
            this.labelAvtors.Text = "Белокуров Е.А. (инженер-исследователь 3 категории) \r\n   Хорошев В.Е. (научная рота)";
        }

        private void OK_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void About_FormClosing(object sender, FormClosingEventArgs e)
        {
            form.closeabout();
        }
    }
}
