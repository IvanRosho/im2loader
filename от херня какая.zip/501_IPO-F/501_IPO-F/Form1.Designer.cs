﻿namespace IPOF_Converter
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.конвертироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьВсеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Add_files = new System.Windows.Forms.Button();
            this.Convert_files = new System.Windows.Forms.Button();
            this.Del_file = new System.Windows.Forms.Button();
            this.Del_All_files = new System.Windows.Forms.Button();
            this.Exit_file = new System.Windows.Forms.Button();
            this.Save_files = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.Files_Box = new System.Windows.Forms.ListBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1439, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem,
            this.конвертироватьToolStripMenuItem,
            this.удалитьToolStripMenuItem,
            this.удалитьВсеToolStripMenuItem,
            this.сохранитьToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // добавитьToolStripMenuItem
            // 
            this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.добавитьToolStripMenuItem.Text = "Добавить";
            this.добавитьToolStripMenuItem.Click += new System.EventHandler(this.ДобавитьToolStripMenuItem_Click);
            // 
            // конвертироватьToolStripMenuItem
            // 
            this.конвертироватьToolStripMenuItem.Name = "конвертироватьToolStripMenuItem";
            this.конвертироватьToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.конвертироватьToolStripMenuItem.Text = "Конвертировать";
            // 
            // удалитьToolStripMenuItem
            // 
            this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.удалитьToolStripMenuItem.Text = "Удалить";
            this.удалитьToolStripMenuItem.Click += new System.EventHandler(this.УдалитьToolStripMenuItem_Click);
            // 
            // удалитьВсеToolStripMenuItem
            // 
            this.удалитьВсеToolStripMenuItem.Name = "удалитьВсеToolStripMenuItem";
            this.удалитьВсеToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.удалитьВсеToolStripMenuItem.Text = "Удалить все";
            this.удалитьВсеToolStripMenuItem.Click += new System.EventHandler(this.УдалитьВсеToolStripMenuItem_Click);
            // 
            // сохранитьToolStripMenuItem
            // 
            this.сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
            this.сохранитьToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.сохранитьToolStripMenuItem.Text = "Сохранить";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.ВыходToolStripMenuItem_Click);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.ОПрограммеToolStripMenuItem_Click);
            // 
            // Add_files
            // 
            this.Add_files.Location = new System.Drawing.Point(12, 27);
            this.Add_files.Name = "Add_files";
            this.Add_files.Size = new System.Drawing.Size(180, 25);
            this.Add_files.TabIndex = 1;
            this.Add_files.Text = "Добавить файл(ы)";
            this.Add_files.UseVisualStyleBackColor = true;
            this.Add_files.Click += new System.EventHandler(this.Add_files_Click);
            // 
            // Convert_files
            // 
            this.Convert_files.Location = new System.Drawing.Point(12, 58);
            this.Convert_files.Name = "Convert_files";
            this.Convert_files.Size = new System.Drawing.Size(180, 25);
            this.Convert_files.TabIndex = 2;
            this.Convert_files.Text = "Конвертировать файл(ы) в XML";
            this.Convert_files.UseVisualStyleBackColor = true;
            // 
            // Del_file
            // 
            this.Del_file.Location = new System.Drawing.Point(198, 27);
            this.Del_file.Name = "Del_file";
            this.Del_file.Size = new System.Drawing.Size(180, 25);
            this.Del_file.TabIndex = 3;
            this.Del_file.Text = "Убрать файл из очереди";
            this.Del_file.UseVisualStyleBackColor = true;
            this.Del_file.Click += new System.EventHandler(this.Del_file_Click);
            // 
            // Del_All_files
            // 
            this.Del_All_files.Location = new System.Drawing.Point(198, 58);
            this.Del_All_files.Name = "Del_All_files";
            this.Del_All_files.Size = new System.Drawing.Size(180, 25);
            this.Del_All_files.TabIndex = 4;
            this.Del_All_files.Text = "Убрать все файлы из очереди";
            this.Del_All_files.UseVisualStyleBackColor = true;
            this.Del_All_files.Click += new System.EventHandler(this.Del_All_files_Click);
            // 
            // Exit_file
            // 
            this.Exit_file.Location = new System.Drawing.Point(792, 27);
            this.Exit_file.Name = "Exit_file";
            this.Exit_file.Size = new System.Drawing.Size(180, 25);
            this.Exit_file.TabIndex = 5;
            this.Exit_file.Text = "Выход из программы";
            this.Exit_file.UseVisualStyleBackColor = true;
            this.Exit_file.Click += new System.EventHandler(this.Exit_file_Click);
            // 
            // Save_files
            // 
            this.Save_files.Location = new System.Drawing.Point(12, 89);
            this.Save_files.Name = "Save_files";
            this.Save_files.Size = new System.Drawing.Size(180, 25);
            this.Save_files.TabIndex = 6;
            this.Save_files.Text = "Конвертировать файл(ы) в im2";
            this.Save_files.UseVisualStyleBackColor = true;
            this.Save_files.Click += new System.EventHandler(this.Save_files_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "TIFF Файлы|*.tif";
            this.openFileDialog1.Multiselect = true;
            this.openFileDialog1.Title = "Выберите файл(ы)";
            // 
            // Files_Box
            // 
            this.Files_Box.FormattingEnabled = true;
            this.Files_Box.HorizontalScrollbar = true;
            this.Files_Box.Location = new System.Drawing.Point(14, 137);
            this.Files_Box.Name = "Files_Box";
            this.Files_Box.Size = new System.Drawing.Size(652, 290);
            this.Files_Box.TabIndex = 7;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(792, 135);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(497, 290);
            this.listBox1.TabIndex = 8;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(666, 184);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(120, 316);
            this.listBox2.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1439, 512);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.Files_Box);
            this.Controls.Add(this.Save_files);
            this.Controls.Add(this.Exit_file);
            this.Controls.Add(this.Del_All_files);
            this.Controls.Add(this.Del_file);
            this.Controls.Add(this.Convert_files);
            this.Controls.Add(this.Add_files);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Конвертер: файл(ы) формата tiff в файл(ы) формата im2 и xml";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem конвертироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.Button Add_files;
        private System.Windows.Forms.Button Convert_files;
        private System.Windows.Forms.Button Del_file;
        private System.Windows.Forms.Button Del_All_files;
        private System.Windows.Forms.Button Exit_file;
        private System.Windows.Forms.ToolStripMenuItem удалитьВсеToolStripMenuItem;
        private System.Windows.Forms.Button Save_files;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ListBox Files_Box;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ListBox listBox2;
    }
}

