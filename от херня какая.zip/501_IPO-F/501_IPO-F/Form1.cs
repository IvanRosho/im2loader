﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using IDZ1_library;

namespace IPOF_Converter
{
    struct IFH
    {
        public string descriptor;
        public uint version;
        public ulong first_directory_pointer;
        public string meta;

    }

    struct Tag
    {
        public uint tag_id;
        public uint type_id;
        public ulong length;
        public ulong offset;
        public int value;
    }


    public partial class Form1 : Form
    {
        public List<string> accompaning = new List<string>();
        private List<string> pathes = new List<string>();
        About about;
        ushort NumTags;
        ulong offset_meta;
        byte h, w;
        string h1, w1;
        uint ww ;
        uint hh ;
        private IDZ1 parameters;
        /// <summary>
        /// idz список файлов
        /// </summary>
        private List<IDZ1> idz1 = new List<IDZ1>();
        /// <summary>
        /// Пути к файлам для конвертации
        /// </summary>

        IFH ifh;
        Tag[] tags;


        public Form1()
        {
            InitializeComponent();
        }
        
        private void ОПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            about = new About(this);
            about.Show();
        }
        public void closeabout()
        {
            about = null;
        }

        // Добавить файл(ы)
        private void Add_files_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.CheckFileExists = true;
            openFileDialog.AddExtension = true;
            openFileDialog.Multiselect = true;
            openFileDialog.RestoreDirectory = true;
            openFileDialog.InitialDirectory = @"D:\Khoroshev\Файлы для Влада\камера\1\test xi con_files\";
            openFileDialog.Filter = "TIFF files (*.tif)|*.tif";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
                Files_Box.Items.AddRange(openFileDialog.FileNames);
        }
        private void ДобавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Add_files_Click(this, new EventArgs());
        }

        // Удалить файл(ы)
        private void Del_file_Click(object sender, EventArgs e)
        {
            if (Files_Box.SelectedIndex != -1)
            {
                Files_Box.Items.RemoveAt(Files_Box.SelectedIndex);
            }
        }
        private void Del_All_files_Click(object sender, EventArgs e)
        {          
                Files_Box.Items.Clear();         
        }
        private void УдалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Del_file_Click(this, new EventArgs());
        }
        private void УдалитьВсеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Del_All_files_Click(this, new EventArgs());
        }


        // Сохранить файл(ы)                     ////////////////////////////////////////////////////////////////
        private void Save_files_Click(object sender, EventArgs e)
        {
            string pathfile = Files_Box.SelectedItem.ToString();
            using (BinaryReader reader = new BinaryReader(File.Open(pathfile, FileMode.Open)))
            {
                ifh.descriptor = reader.ReadChar().ToString() + reader.ReadChar().ToString();
                ifh.version = reader.ReadUInt16();
               
                ifh.first_directory_pointer = reader.ReadUInt32();
                if (ifh.first_directory_pointer < 0)
                    throw new Exception("Directory pointer is too far.");
                reader.BaseStream.Position = (long)ifh.first_directory_pointer;

                NumTags = reader.ReadUInt16();
                tags = new Tag[NumTags];
                for (int i = 0; i < NumTags; i++)
                {
                    tags[i].tag_id = reader.ReadUInt16();
                    tags[i].type_id = reader.ReadUInt16();
                    tags[i].length = reader.ReadUInt32();
                    tags[i].offset = reader.ReadUInt32();
                    if (tags[i].tag_id == 270)
                    {
                        offset_meta = tags[i].offset;
                    }
                    //ширина
                    if (tags[i].tag_id == 256)
                    {
                        w = (byte)tags[i].offset;
                        w1 = tags[i].offset.ToString();
                    }
                    //высота
                    if (tags[i].tag_id == 257)
                    {
                        h = (byte)tags[i].offset;
                        h1 = tags[i].offset.ToString();
                    }                    
                }
                listBox2.Items.Add(h + "                      " + w);
                listBox2.Items.Add("      " + h1 + "    " + w1);
            }
            string tt = pathfile;
            using (FileStream fstream = File.OpenRead(tt))
            {
                // преобразуем строку в байты
                byte[] array = new byte[(int)ifh.first_directory_pointer];
                // считываем данные                         
                //fstream.Position = 8;

                //listBox2.Items.Add(array.Length);                     // 900920

                fstream.Read(array, 0, array.Length);   // ЧИТАЕМ СТАРЫЙ

                byte[] newArray = new byte[(array.Length-8) + 512];   // Делаем новый массив 

                //listBox2.Items.Add(newArray.Length);                     // 901424

                int ww1 = int.Parse(w1);
                int hh1 = int.Parse(h1);

                for (int i = 0; i < 512; i++)     // (<--- тут) Вот теперь запись строк и столбюцов верная
                {
                    if (i == 500)
                    {
                        byte[] W = BitConverter.GetBytes((short)ww1);
                        //Array.Reverse(W);
                        byte[] H = BitConverter.GetBytes((short)hh1);
                        //Array.Reverse(H);
                        newArray[i] = W[0]; newArray[i + 1] = W[1]; newArray[i + 2] = H[0]; newArray[i + 3] = H[1];
                        i += 4; // Уже выше (вот только) записали 4 байта...
                    }
                    else newArray[i] = (byte)32;
                }

                byte[] ImaArray = new byte[ww1 * hh1 * 2]; // Готовим кадр:
                for (int i = 0; i < ImaArray.Length; i++) // Изображение (copy)
                {
                    ImaArray[i] = array[i + 8];
                }
                for (int i = 0; i < ImaArray.Length; i++)
                {
                    BitConverter.GetBytes((ushort)ImaArray[i]);
                }



                //for (int i = 0; i <ImaArray.Length ; i++)
                //{
                //    BitConverter.GetBytes((ushort)ImaArray[i]);
                //}
                ImaArray.CopyTo(newArray, 512);



                //listBox2.Items.Add("             ");                     // 901432
                //listBox2.Items.Add("Я понял это как:");                     // 901432
                //listBox2.Items.Add(newArray[500] + "         " + newArray[501]);                     // 901432
                //listBox2.Items.Add("  " + newArray[502] + "  " + newArray[503]);                     // 901432


                tt = tt.Substring(tt.Length - 10);             // Формирование и запись файла
                tt = tt.Replace(".tif", ".im2");
                bool showdialog = true;
                if (showdialog)
                {
                    saveFileDialog1.FileName = tt;
                    saveFileDialog1.RestoreDirectory = true;
                    saveFileDialog1.InitialDirectory = @"D:\Khoroshev\ImgToIdz Converter\im2\";
                    saveFileDialog1.Filter = "IM2 files (*.im2)|*.im2";
                    if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        using (FileStream srt = new FileStream(saveFileDialog1.FileName, FileMode.OpenOrCreate))
                        {                           
                            srt.Write(newArray, 0, newArray.Length);
                            fstream.Close();
                        }
                        listBox1.Items.Add(saveFileDialog1.FileName);
                        showdialog = false;
                    }
                    else
                        return;
                }
            }
        }


        // Выход из программы
        private void Exit_file_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void ВыходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exit_file_Click(this, new EventArgs());
        }
    }
}
