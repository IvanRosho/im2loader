﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IDZ1_library;


namespace IPO_F
{
    public partial class Form1 : Form
    {
        /* В начале программы
         *      мы объявляем 
         *          все параметры
         *              и даже форму (о программе)!
         */
        // Параметры:
        string[] files_tif;
        int w, h;
        // Форма (о программе):
        About about;
        // Теги:
        struct IFH
        {
            public string descriptor;
            public uint version;
            public ulong first_directory_pointer;
            public string meta;

        }
        struct Tag
        {
            public uint tag_id;
            public uint type_id;
            public ulong length;
            public ulong offset;
            public int value;
        }
        ushort NumTags;
        IFH ifh;
        Tag[] tags;

        public Form1()
        {
            InitializeComponent();
        }

        #region About
        /* Информация о программе!
         */
        private void ОПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            about = new About(this);
            about.Show();
        }
        public void closeabout()
        {
            about = null;
        }
        #endregion

        #region Load
        // Загрузка файлов:
        private void Add_files_Click(object sender, EventArgs e)
        {
            openFileDialog_tif.Multiselect = true;
            if (openFileDialog_tif.ShowDialog() == DialogResult.OK)
            {
                files_tif = openFileDialog_tif.FileNames;
                Files_Box_tif.Items.Clear();
                Files_Box_tif.Items.AddRange(files_tif);
                Check_files();
            }
        }
        private void ЗагрузитьФайлыФорматаTifToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Add_files_Click(this, new EventArgs());
        }
        #endregion




        // Метод Загрузки для однокадровых файлов tif:
        public int[,] LoadFile(string _file)
        {
            int[,] frame;
            using (BinaryReader reader = new BinaryReader(File.Open(_file, FileMode.Open)))
            {
                reader.BaseStream.Position = 54; int ww = reader.ReadUInt16(); ww = 822;  // (<--- тут) Читаем количество столбцов.
                reader.BaseStream.Position = 36; int hh = reader.ReadUInt16(); hh = 548;  // (<--- тут) Читаем количество строк.


                listBox1.Items.Add(ww);  // временно проверяем
                listBox1.Items.Add(hh);  // временно проверяем


                if (w == 0 || h == 0)
                { // Если размеры еще не распарсены, то парсим их:
                    w = ww;
                    h = hh;
                }
                frame = new int[w,h];
                reader.BaseStream.Position = 8; // Приступаем к чтению:
                byte[] arr = reader.ReadBytes(w * h * 2); // Читаем сразу весь кусок:
                int cur = 0;
                for (int i = 0; i < h; i++)
                    for (int j = 0; j < w; j++)
                    {
                        frame[j, i] = BitConverter.ToUInt16(arr, cur);// (<--- тут) Парсим массив в памяти, суммируем кадры.
                        cur+=2;
                    }
            }
            return frame;
        }

        // Метод сохранения файла im2, полученного из совокупности однокадровых:
        private void SaveFile(string newFile, int[,] frame)
        {
            using (BinaryWriter writer = new BinaryWriter(File.OpenWrite(newFile)))
            {
                writer.BaseStream.Position = writer.BaseStream.Length; //перенос курсора в конец файла
                byte [] head = new byte[w * h * 2]; // Готовим кадр:
                using (MemoryStream stream = new MemoryStream(head))
                {
                    for (int i = 0; i < h; i++)
                        for (int j = 0; j < w; j++) stream.Write(BitConverter.GetBytes((ushort)frame[j,i]), 0, 2);
                }
                writer.Write(head); // (<--- тут) Пишем кадр одним куском.
            }
        }






        #region Convert
        // Однокадровых:
        private void Convert_file_Click(object sender, EventArgs e)
        {
            try
            {
                this.Enabled = false;
                ProgressBar.Maximum = Files_Box_tif.Items.Count;
                ProgressBar.Value = 0;
                ProgressBar.Step = 1;
                ProgressBar.Visible = true;
                int ww = 822; int hh = 548; int k = Files_Box_tif.Items.Count;
                string newFile;
                newFile = Path.GetFileNameWithoutExtension(files_tif[0]) + "new.im2";
                newFile = Path.Combine(Path.GetDirectoryName(files_tif[0]), newFile); //путь до нового файла

                using (BinaryWriter writer = new BinaryWriter(File.Create(newFile)))
                {
                    // Пишем шапку:
                    byte[] head = new byte[512];   // (<--- тут) Делаем новый массив 
                    for (int i = 0; i < 512; i++)     // Запись строк и столбюцов верная:
                    {
                        if (i == 500)
                        {
                            byte[] W = BitConverter.GetBytes((short)ww);  // (<--- тут) 2 байта о столбцах.
                            byte[] H = BitConverter.GetBytes((short)hh);  // (<--- тут) 2 байта о строках.
                            head[i] = W[0]; head[i + 1] = W[1]; head[i + 2] = H[0]; head[i + 3] = H[1];
                            i += 4; // Уже выше (вот только) записали 4 байта...
                        }
                        else head[i] = (byte)32;
                    }
                    writer.Write(head);

                }
                // Пишем кадры один за одним

                foreach (string file in files_tif)  // По каждому файлу:
                {
                    SaveFile(newFile, LoadFile(file));
                    //SaveFile(newFile,LoadFileByte(file));
                    ProgressBar.PerformStep();
                }


                Files_im2.Enabled = true;
                Files_xml.Enabled = true;
                MessageBox.Show("Успешно создан новый файл");
            }
            catch (DivideByZeroException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка обработки", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.Enabled = true;
                ProgressBar.Visible = false;
            }
        }
        private void ОднокадровыеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Convert_file_Click(this, new EventArgs());
        }
        // Многокадровых:
        private void Convert_files_Click(object sender, EventArgs e)
        {


            Files_im2.Enabled = true;
            Files_xml.Enabled = true;
        }
        private void МногокадровыеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Convert_files_Click(this, new EventArgs());
        }
        #endregion

        #region Delete
        // Удаление файлов:
        private void Del_All_files_Click(object sender, EventArgs e)
        {
            Files_Box_tif.Items.Clear();
            Files_im2.Items.Clear();
            Files_xml.Items.Clear();
            Check_files_detect();
        }
        private void УдалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Del_All_files_Click(this, new EventArgs());
        }
        // Выпадающее меню для tif:
        private void СнятьВыделениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Files_Box_tif.SelectedIndex = -1;
        }
        private void ОчиститьПолеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Files_Box_tif.Items.Clear();
            Check_files_detect();
        }
        private void УбратьФайлToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Files_Box_tif.SelectedIndex != -1) Files_Box_tif.Items.RemoveAt(Files_Box_tif.SelectedIndex);
            if (Files_Box_tif.Items.Count == 0) Check_files_detect();
        }
        // Выпадающее меню для im2:
        private void СнятьВыделениеToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Files_im2.SelectedIndex = -1;
        }
        private void ОчиститьПолеToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Files_im2.Items.Clear();
        }
        private void УбратьФайлToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (Files_im2.SelectedIndex != -1) Files_im2.Items.RemoveAt(Files_im2.SelectedIndex);
        }
        // Выпадающее меню для xml:
        private void СнятьВыделениеToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Files_xml.SelectedIndex = -1;
        }
        private void ОчиститьПолеToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Files_xml.Items.Clear();
        }
        private void УбратьФайлToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (Files_xml.SelectedIndex != -1) Files_xml.Items.RemoveAt(Files_xml.SelectedIndex);
        }
        #endregion

        #region Exit
        private void ВыходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #endregion

   

















        #region Nyshtiaki
        // Цвета кнопок при наведении и покидании мышью:
        private void btn_MouseHover(object sender, EventArgs e)
        {
            (sender as Button).BackColor = Color.Green;
        }
        private void btn_MouseLeave(object sender, EventArgs e)
        {
            (sender as Button).BackColor = Color.Gainsboro;
        }










        // Проверка наличия файлов (включение кнопок):
        private void Check_files()
        {
            Files_Box_tif.Enabled = true;
            Del_All_files.Enabled = true;
            Convert_file.Enabled = true;
            Convert_files.Enabled = true;
        }
        // Проверка наличия файлов (отключение кнопок):
        private void Check_files_detect()
        {
            Files_im2.Enabled = false;
            Files_xml.Enabled = false;
            Files_Box_tif.Enabled = false;
            Del_All_files.Enabled = false;
            Convert_file.Enabled = false;
            Convert_files.Enabled = false;
        }
        #endregion
    }
}
