﻿namespace IPO_F
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Add_files = new System.Windows.Forms.Button();
            this.Convert_file = new System.Windows.Forms.Button();
            this.Convert_files = new System.Windows.Forms.Button();
            this.Del_All_files = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.Files_Box_tif = new System.Windows.Forms.ListBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.снятьВыделениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.очиститьПолеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.убратьФайлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Files_im2 = new System.Windows.Forms.ListBox();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.снятьВыделениеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.очиститьПолеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.убратьФайлToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Files_xml = new System.Windows.Forms.ListBox();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.снятьВыделениеToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.очиститьПолеToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.убратьФайлToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Load_Files = new System.Windows.Forms.Label();
            this.openFileDialog_tif = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.загрузитьФайлыФорматаTifToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.конвертироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.однокадровыеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.многокадровыеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Converter_im2 = new System.Windows.Forms.Label();
            this.Converter_xml = new System.Windows.Forms.Label();
            this.ProgressBar = new System.Windows.Forms.ProgressBar();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.contextMenuStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.contextMenuStrip3.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Add_files
            // 
            this.Add_files.BackColor = System.Drawing.Color.Gainsboro;
            this.Add_files.Location = new System.Drawing.Point(500, 30);
            this.Add_files.Name = "Add_files";
            this.Add_files.Size = new System.Drawing.Size(180, 25);
            this.Add_files.TabIndex = 0;
            this.Add_files.Text = "Добавить файл(ы)";
            this.Add_files.UseVisualStyleBackColor = false;
            this.Add_files.Click += new System.EventHandler(this.Add_files_Click);
            this.Add_files.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.Add_files.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // Convert_file
            // 
            this.Convert_file.BackColor = System.Drawing.Color.Gainsboro;
            this.Convert_file.Enabled = false;
            this.Convert_file.Location = new System.Drawing.Point(500, 60);
            this.Convert_file.Name = "Convert_file";
            this.Convert_file.Size = new System.Drawing.Size(180, 40);
            this.Convert_file.TabIndex = 1;
            this.Convert_file.Text = "Конвертировать однокадровые файлы";
            this.Convert_file.UseVisualStyleBackColor = false;
            this.Convert_file.Click += new System.EventHandler(this.Convert_file_Click);
            this.Convert_file.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.Convert_file.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // Convert_files
            // 
            this.Convert_files.BackColor = System.Drawing.Color.Gainsboro;
            this.Convert_files.Enabled = false;
            this.Convert_files.Location = new System.Drawing.Point(700, 60);
            this.Convert_files.Name = "Convert_files";
            this.Convert_files.Size = new System.Drawing.Size(180, 40);
            this.Convert_files.TabIndex = 2;
            this.Convert_files.Text = "Конвертировать многокадровые файлы";
            this.Convert_files.UseVisualStyleBackColor = false;
            this.Convert_files.Click += new System.EventHandler(this.Convert_files_Click);
            this.Convert_files.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.Convert_files.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // Del_All_files
            // 
            this.Del_All_files.BackColor = System.Drawing.Color.Gainsboro;
            this.Del_All_files.Enabled = false;
            this.Del_All_files.Location = new System.Drawing.Point(700, 30);
            this.Del_All_files.Name = "Del_All_files";
            this.Del_All_files.Size = new System.Drawing.Size(180, 25);
            this.Del_All_files.TabIndex = 4;
            this.Del_All_files.Text = "Удалить все файлы";
            this.Del_All_files.UseVisualStyleBackColor = false;
            this.Del_All_files.Click += new System.EventHandler(this.Del_All_files_Click);
            this.Del_All_files.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.Del_All_files.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(518, 389);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 5;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // Files_Box_tif
            // 
            this.Files_Box_tif.ContextMenuStrip = this.contextMenuStrip1;
            this.Files_Box_tif.Enabled = false;
            this.Files_Box_tif.FormattingEnabled = true;
            this.Files_Box_tif.HorizontalScrollbar = true;
            this.Files_Box_tif.Location = new System.Drawing.Point(25, 65);
            this.Files_Box_tif.Name = "Files_Box_tif";
            this.Files_Box_tif.Size = new System.Drawing.Size(400, 459);
            this.Files_Box_tif.TabIndex = 6;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.снятьВыделениеToolStripMenuItem,
            this.очиститьПолеToolStripMenuItem,
            this.убратьФайлToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(170, 70);
            // 
            // снятьВыделениеToolStripMenuItem
            // 
            this.снятьВыделениеToolStripMenuItem.Name = "снятьВыделениеToolStripMenuItem";
            this.снятьВыделениеToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.снятьВыделениеToolStripMenuItem.Text = "Снять выделение";
            this.снятьВыделениеToolStripMenuItem.Click += new System.EventHandler(this.СнятьВыделениеToolStripMenuItem_Click);
            // 
            // очиститьПолеToolStripMenuItem
            // 
            this.очиститьПолеToolStripMenuItem.Name = "очиститьПолеToolStripMenuItem";
            this.очиститьПолеToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.очиститьПолеToolStripMenuItem.Text = "Очистить поле";
            this.очиститьПолеToolStripMenuItem.Click += new System.EventHandler(this.ОчиститьПолеToolStripMenuItem_Click);
            // 
            // убратьФайлToolStripMenuItem
            // 
            this.убратьФайлToolStripMenuItem.Name = "убратьФайлToolStripMenuItem";
            this.убратьФайлToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.убратьФайлToolStripMenuItem.Text = "Убрать файл";
            this.убратьФайлToolStripMenuItem.Click += new System.EventHandler(this.УбратьФайлToolStripMenuItem_Click);
            // 
            // Files_im2
            // 
            this.Files_im2.ContextMenuStrip = this.contextMenuStrip2;
            this.Files_im2.Enabled = false;
            this.Files_im2.FormattingEnabled = true;
            this.Files_im2.HorizontalScrollbar = true;
            this.Files_im2.Location = new System.Drawing.Point(490, 140);
            this.Files_im2.Name = "Files_im2";
            this.Files_im2.Size = new System.Drawing.Size(400, 381);
            this.Files_im2.TabIndex = 7;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.снятьВыделениеToolStripMenuItem1,
            this.очиститьПолеToolStripMenuItem1,
            this.убратьФайлToolStripMenuItem1});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(170, 70);
            // 
            // снятьВыделениеToolStripMenuItem1
            // 
            this.снятьВыделениеToolStripMenuItem1.Name = "снятьВыделениеToolStripMenuItem1";
            this.снятьВыделениеToolStripMenuItem1.Size = new System.Drawing.Size(169, 22);
            this.снятьВыделениеToolStripMenuItem1.Text = "Снять выделение";
            this.снятьВыделениеToolStripMenuItem1.Click += new System.EventHandler(this.СнятьВыделениеToolStripMenuItem1_Click);
            // 
            // очиститьПолеToolStripMenuItem1
            // 
            this.очиститьПолеToolStripMenuItem1.Name = "очиститьПолеToolStripMenuItem1";
            this.очиститьПолеToolStripMenuItem1.Size = new System.Drawing.Size(169, 22);
            this.очиститьПолеToolStripMenuItem1.Text = "Очистить поле";
            this.очиститьПолеToolStripMenuItem1.Click += new System.EventHandler(this.ОчиститьПолеToolStripMenuItem1_Click);
            // 
            // убратьФайлToolStripMenuItem1
            // 
            this.убратьФайлToolStripMenuItem1.Name = "убратьФайлToolStripMenuItem1";
            this.убратьФайлToolStripMenuItem1.Size = new System.Drawing.Size(169, 22);
            this.убратьФайлToolStripMenuItem1.Text = "Убрать файл";
            this.убратьФайлToolStripMenuItem1.Click += new System.EventHandler(this.УбратьФайлToolStripMenuItem1_Click);
            // 
            // Files_xml
            // 
            this.Files_xml.ContextMenuStrip = this.contextMenuStrip3;
            this.Files_xml.Enabled = false;
            this.Files_xml.FormattingEnabled = true;
            this.Files_xml.HorizontalScrollbar = true;
            this.Files_xml.Location = new System.Drawing.Point(955, 140);
            this.Files_xml.Name = "Files_xml";
            this.Files_xml.Size = new System.Drawing.Size(400, 381);
            this.Files_xml.TabIndex = 8;
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.снятьВыделениеToolStripMenuItem2,
            this.очиститьПолеToolStripMenuItem2,
            this.убратьФайлToolStripMenuItem2});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(170, 70);
            // 
            // снятьВыделениеToolStripMenuItem2
            // 
            this.снятьВыделениеToolStripMenuItem2.Name = "снятьВыделениеToolStripMenuItem2";
            this.снятьВыделениеToolStripMenuItem2.Size = new System.Drawing.Size(169, 22);
            this.снятьВыделениеToolStripMenuItem2.Text = "Снять выделение";
            this.снятьВыделениеToolStripMenuItem2.Click += new System.EventHandler(this.СнятьВыделениеToolStripMenuItem2_Click);
            // 
            // очиститьПолеToolStripMenuItem2
            // 
            this.очиститьПолеToolStripMenuItem2.Name = "очиститьПолеToolStripMenuItem2";
            this.очиститьПолеToolStripMenuItem2.Size = new System.Drawing.Size(169, 22);
            this.очиститьПолеToolStripMenuItem2.Text = "Очистить поле";
            this.очиститьПолеToolStripMenuItem2.Click += new System.EventHandler(this.ОчиститьПолеToolStripMenuItem2_Click);
            // 
            // убратьФайлToolStripMenuItem2
            // 
            this.убратьФайлToolStripMenuItem2.Name = "убратьФайлToolStripMenuItem2";
            this.убратьФайлToolStripMenuItem2.Size = new System.Drawing.Size(169, 22);
            this.убратьФайлToolStripMenuItem2.Text = "Убрать файл";
            this.убратьФайлToolStripMenuItem2.Click += new System.EventHandler(this.УбратьФайлToolStripMenuItem2_Click);
            // 
            // Load_Files
            // 
            this.Load_Files.AutoSize = true;
            this.Load_Files.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Load_Files.Location = new System.Drawing.Point(25, 40);
            this.Load_Files.Name = "Load_Files";
            this.Load_Files.Size = new System.Drawing.Size(233, 17);
            this.Load_Files.TabIndex = 9;
            this.Load_Files.Text = "Загруженные файлы (формат tiff):";
            this.Load_Files.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // openFileDialog_tif
            // 
            this.openFileDialog_tif.Filter = "TIFF Файлы|*.tif";
            this.openFileDialog_tif.Multiselect = true;
            this.openFileDialog_tif.Title = "Выберите файл(ы):";
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Title = "Укажите путь:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1384, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.загрузитьФайлыФорматаTifToolStripMenuItem,
            this.конвертироватьToolStripMenuItem,
            this.удалитьToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // загрузитьФайлыФорматаTifToolStripMenuItem
            // 
            this.загрузитьФайлыФорматаTifToolStripMenuItem.Name = "загрузитьФайлыФорматаTifToolStripMenuItem";
            this.загрузитьФайлыФорматаTifToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.загрузитьФайлыФорматаTifToolStripMenuItem.Text = "Добавить";
            this.загрузитьФайлыФорматаTifToolStripMenuItem.Click += new System.EventHandler(this.ЗагрузитьФайлыФорматаTifToolStripMenuItem_Click);
            // 
            // конвертироватьToolStripMenuItem
            // 
            this.конвертироватьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.однокадровыеToolStripMenuItem,
            this.многокадровыеToolStripMenuItem});
            this.конвертироватьToolStripMenuItem.Name = "конвертироватьToolStripMenuItem";
            this.конвертироватьToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.конвертироватьToolStripMenuItem.Text = "Конвертировать";
            // 
            // однокадровыеToolStripMenuItem
            // 
            this.однокадровыеToolStripMenuItem.Name = "однокадровыеToolStripMenuItem";
            this.однокадровыеToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.однокадровыеToolStripMenuItem.Text = "однокадровые";
            this.однокадровыеToolStripMenuItem.Click += new System.EventHandler(this.ОднокадровыеToolStripMenuItem_Click);
            // 
            // многокадровыеToolStripMenuItem
            // 
            this.многокадровыеToolStripMenuItem.Name = "многокадровыеToolStripMenuItem";
            this.многокадровыеToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.многокадровыеToolStripMenuItem.Text = "многокадровые";
            this.многокадровыеToolStripMenuItem.Click += new System.EventHandler(this.МногокадровыеToolStripMenuItem_Click);
            // 
            // удалитьToolStripMenuItem
            // 
            this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.удалитьToolStripMenuItem.Text = "Удалить";
            this.удалитьToolStripMenuItem.Click += new System.EventHandler(this.УдалитьToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.ВыходToolStripMenuItem_Click);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.ОПрограммеToolStripMenuItem_Click);
            // 
            // Converter_im2
            // 
            this.Converter_im2.AutoSize = true;
            this.Converter_im2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Converter_im2.Location = new System.Drawing.Point(490, 115);
            this.Converter_im2.Name = "Converter_im2";
            this.Converter_im2.Size = new System.Drawing.Size(280, 17);
            this.Converter_im2.TabIndex = 14;
            this.Converter_im2.Text = "Конвертированные файлы (формат im2):";
            this.Converter_im2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Converter_xml
            // 
            this.Converter_xml.AutoSize = true;
            this.Converter_xml.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Converter_xml.Location = new System.Drawing.Point(955, 115);
            this.Converter_xml.Name = "Converter_xml";
            this.Converter_xml.Size = new System.Drawing.Size(278, 17);
            this.Converter_xml.TabIndex = 15;
            this.Converter_xml.Text = "Конвертированные файлы (формат xml):";
            this.Converter_xml.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // ProgressBar
            // 
            this.ProgressBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ProgressBar.Location = new System.Drawing.Point(0, 539);
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.Size = new System.Drawing.Size(1384, 23);
            this.ProgressBar.TabIndex = 19;
            this.ProgressBar.Visible = false;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(991, 27);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(181, 82);
            this.listBox1.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1384, 562);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.ProgressBar);
            this.Controls.Add(this.Converter_xml);
            this.Controls.Add(this.Converter_im2);
            this.Controls.Add(this.Load_Files);
            this.Controls.Add(this.Files_xml);
            this.Controls.Add(this.Files_im2);
            this.Controls.Add(this.Files_Box_tif);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.Del_All_files);
            this.Controls.Add(this.Convert_files);
            this.Controls.Add(this.Convert_file);
            this.Controls.Add(this.Add_files);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.contextMenuStrip1.ResumeLayout(false);
            this.contextMenuStrip2.ResumeLayout(false);
            this.contextMenuStrip3.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Add_files;
        private System.Windows.Forms.Button Convert_file;
        private System.Windows.Forms.Button Convert_files;
        private System.Windows.Forms.Button Del_All_files;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ListBox Files_Box_tif;
        private System.Windows.Forms.ListBox Files_im2;
        private System.Windows.Forms.ListBox Files_xml;
        private System.Windows.Forms.Label Load_Files;
        private System.Windows.Forms.OpenFileDialog openFileDialog_tif;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem загрузитьФайлыФорматаTifToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem конвертироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.Label Converter_im2;
        private System.Windows.Forms.Label Converter_xml;
        private System.Windows.Forms.ProgressBar ProgressBar;
        private System.Windows.Forms.ToolStripMenuItem однокадровыеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem многокадровыеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem снятьВыделениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem очиститьПолеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem снятьВыделениеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem снятьВыделениеToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem очиститьПолеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem очиститьПолеToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem убратьФайлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem убратьФайлToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem убратьФайлToolStripMenuItem2;
        private System.Windows.Forms.ListBox listBox1;
    }
}

