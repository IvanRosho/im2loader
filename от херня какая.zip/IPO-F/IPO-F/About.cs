﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Windows.Forms;

namespace IPO_F
{
    public partial class About : Form
    {
        Form1 form;
        public About(Form1 f)
        {
            InitializeComponent();
            form = f;
            this.Text = String.Format("Title {0}", AssemblyTitle);
            this.labelProductName.Text = AssemblyProduct;
            this.labelVersion.Text = "Version 1.1";
            this.labelCopyright.Text = AssemblyCopyright;
            this.labelCompanyName.Text = AssemblyCompany;
            this.textBoxDescription.Text = "Описание: \r\n" +
            "     Специализированное програмное обеспечение подготовки и " +
            "обработки файлов, содержащих видеоданные и служебную " +
            "информацию от УФРС и/или КВК. \r\n \r\n" +
           "Обеспечивается выполнение следующих функций: \r\n" +
            "   - файловый обмен с ПО УУ Д; \r\n" +
            "   - загрузка блоков видеоданных и блоков служебной информации " +
            "из файлов, полученных от УФРС, и/или файлов, полученных КВК; \r\n" +
            "   - формирование и запись файла ВИ формата «im2» и файла " +
            "метаданных формата «xml» из файлов, полученных от УФРС " +
            "и/или КВК. \r\n";
            this.labelAvtors.Text = "Белокуров Е.А. (инженер-исследователь 3 категории) \r\n   Хорошев В.Е. (научная рота)";
        }

        public string AssemblyTitle
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                if (attributes.Length > 0)
                {
                    AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                    if (titleAttribute.Title != "")
                    {
                        return titleAttribute.Title;
                    }
                }
                return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
            }
        }

        public string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        public string AssemblyDescription
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyDescriptionAttribute)attributes[0]).Description;
            }
        }

        public string AssemblyProduct
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyProductAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyProductAttribute)attributes[0]).Product;
            }
        }

        public string AssemblyCopyright
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
            }
        }

        public string AssemblyCompany
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCompanyAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCompanyAttribute)attributes[0]).Company;
            }
        }

        private void OK_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void About_FormClosing(object sender, FormClosingEventArgs e)
        {
            form.closeabout();
        }
    }
}
