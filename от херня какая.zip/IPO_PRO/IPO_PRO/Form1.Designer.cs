﻿namespace IPO_PRO
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.темноаойФайлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.фактДефектныхЭлементныхToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.текстовыйФайлXmlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.световойсветовыеФайлыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.расчитатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.усреднениеПоЧислуКадровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.коррекцияТемновогоСигналаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.коррекцияДефектныхЭлементовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ОчиститьполяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выделенныйФайлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.всеФайлыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Svet_files = new System.Windows.Forms.Button();
            this.XML_file = new System.Windows.Forms.Button();
            this.Temno_file = new System.Windows.Forms.Button();
            this.Defect_file = new System.Windows.Forms.Button();
            this.Adres_Temno_file = new System.Windows.Forms.Label();
            this.Adres_Defect_file = new System.Windows.Forms.Label();
            this.Adres_XML_file = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TB_Temno_file = new System.Windows.Forms.TextBox();
            this.TB__Defect_file = new System.Windows.Forms.TextBox();
            this.TB_XML_file = new System.Windows.Forms.TextBox();
            this.LIST_svet_files = new System.Windows.Forms.ListBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.снятьВыделениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TB_XML_Description = new System.Windows.Forms.TextBox();
            this.btn_srednee = new System.Windows.Forms.Button();
            this.openFileDialog_im2 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog_xml = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.DeliteAll = new System.Windows.Forms.Button();
            this.Otobrajenie = new System.Windows.Forms.Label();
            this.RB_temno_show = new System.Windows.Forms.RadioButton();
            this.RB_svet_clear_show = new System.Windows.Forms.RadioButton();
            this.Delite1 = new System.Windows.Forms.Button();
            this.pictureBoxkadr = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.TB_Report = new System.Windows.Forms.TextBox();
            this.chartSTB = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartSTR = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_correcttemno = new System.Windows.Forms.Button();
            this.btn_correctdefect = new System.Windows.Forms.Button();
            this.KadrCount = new System.Windows.Forms.Label();
            this.TrackBarKadr = new System.Windows.Forms.TrackBar();
            this.ProgressBar = new System.Windows.Forms.ProgressBar();
            this.RB_svet_temno_show = new System.Windows.Forms.RadioButton();
            this.RB_svet_def_show = new System.Windows.Forms.RadioButton();
            this.btn_delKadr = new System.Windows.Forms.Button();
            this.lbx_delKadr = new System.Windows.Forms.ListBox();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.снятьВыделениеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.label_del_kadr = new System.Windows.Forms.Label();
            this.l_XML_Description = new System.Windows.Forms.Label();
            this.openFileDialog_txt = new System.Windows.Forms.OpenFileDialog();
            this.KadrNumber = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxkadr)).BeginInit();
            this.tableLayoutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartSTB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartSTR)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TrackBarKadr)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1384, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem,
            this.расчитатьToolStripMenuItem,
            this.ОчиститьполяToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // добавитьToolStripMenuItem
            // 
            this.добавитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.темноаойФайлToolStripMenuItem,
            this.фактДефектныхЭлементныхToolStripMenuItem,
            this.текстовыйФайлXmlToolStripMenuItem,
            this.световойсветовыеФайлыToolStripMenuItem});
            this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.добавитьToolStripMenuItem.Text = "Загрузить";
            // 
            // темноаойФайлToolStripMenuItem
            // 
            this.темноаойФайлToolStripMenuItem.Name = "темноаойФайлToolStripMenuItem";
            this.темноаойФайлToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.темноаойФайлToolStripMenuItem.Text = "темноаой файл";
            this.темноаойФайлToolStripMenuItem.Click += new System.EventHandler(this.ТемноаойФайлToolStripMenuItem_Click);
            // 
            // фактДефектныхЭлементныхToolStripMenuItem
            // 
            this.фактДефектныхЭлементныхToolStripMenuItem.Name = "фактДефектныхЭлементныхToolStripMenuItem";
            this.фактДефектныхЭлементныхToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.фактДефектныхЭлементныхToolStripMenuItem.Text = "файл дефектных элементов";
            this.фактДефектныхЭлементныхToolStripMenuItem.Click += new System.EventHandler(this.ФайлДефектныхЭлементовToolStripMenuItem_Click);
            // 
            // текстовыйФайлXmlToolStripMenuItem
            // 
            this.текстовыйФайлXmlToolStripMenuItem.Name = "текстовыйФайлXmlToolStripMenuItem";
            this.текстовыйФайлXmlToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.текстовыйФайлXmlToolStripMenuItem.Text = "текстовый файл xml";
            this.текстовыйФайлXmlToolStripMenuItem.Click += new System.EventHandler(this.ТекстовыйФайлXmlToolStripMenuItem_Click);
            // 
            // световойсветовыеФайлыToolStripMenuItem
            // 
            this.световойсветовыеФайлыToolStripMenuItem.Name = "световойсветовыеФайлыToolStripMenuItem";
            this.световойсветовыеФайлыToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.световойсветовыеФайлыToolStripMenuItem.Text = "световой/световые файл(ы)";
            this.световойсветовыеФайлыToolStripMenuItem.Click += new System.EventHandler(this.СветовойсветовыеФайлыToolStripMenuItem_Click);
            // 
            // расчитатьToolStripMenuItem
            // 
            this.расчитатьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.усреднениеПоЧислуКадровToolStripMenuItem,
            this.коррекцияТемновогоСигналаToolStripMenuItem,
            this.коррекцияДефектныхЭлементовToolStripMenuItem});
            this.расчитатьToolStripMenuItem.Name = "расчитатьToolStripMenuItem";
            this.расчитатьToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.расчитатьToolStripMenuItem.Text = "Обработать";
            // 
            // усреднениеПоЧислуКадровToolStripMenuItem
            // 
            this.усреднениеПоЧислуКадровToolStripMenuItem.Name = "усреднениеПоЧислуКадровToolStripMenuItem";
            this.усреднениеПоЧислуКадровToolStripMenuItem.Size = new System.Drawing.Size(258, 22);
            this.усреднениеПоЧислуКадровToolStripMenuItem.Text = "Усреднение по числу кадров";
            this.усреднениеПоЧислуКадровToolStripMenuItem.Click += new System.EventHandler(this.УсреднениеПоЧислуКадровToolStripMenuItem_Click);
            // 
            // коррекцияТемновогоСигналаToolStripMenuItem
            // 
            this.коррекцияТемновогоСигналаToolStripMenuItem.Name = "коррекцияТемновогоСигналаToolStripMenuItem";
            this.коррекцияТемновогоСигналаToolStripMenuItem.Size = new System.Drawing.Size(258, 22);
            this.коррекцияТемновогоСигналаToolStripMenuItem.Text = "Коррекция темнового сигнала";
            this.коррекцияТемновогоСигналаToolStripMenuItem.Click += new System.EventHandler(this.КоррекцияТемновогоСигналаToolStripMenuItem_Click);
            // 
            // коррекцияДефектныхЭлементовToolStripMenuItem
            // 
            this.коррекцияДефектныхЭлементовToolStripMenuItem.Name = "коррекцияДефектныхЭлементовToolStripMenuItem";
            this.коррекцияДефектныхЭлементовToolStripMenuItem.Size = new System.Drawing.Size(258, 22);
            this.коррекцияДефектныхЭлементовToolStripMenuItem.Text = "Коррекция дефектных элементов";
            this.коррекцияДефектныхЭлементовToolStripMenuItem.Click += new System.EventHandler(this.КоррекцияДефектныхЭлементовToolStripMenuItem_Click);
            // 
            // ОчиститьполяToolStripMenuItem
            // 
            this.ОчиститьполяToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выделенныйФайлToolStripMenuItem,
            this.всеФайлыToolStripMenuItem});
            this.ОчиститьполяToolStripMenuItem.Name = "ОчиститьполяToolStripMenuItem";
            this.ОчиститьполяToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.ОчиститьполяToolStripMenuItem.Text = "Удалить";
            // 
            // выделенныйФайлToolStripMenuItem
            // 
            this.выделенныйФайлToolStripMenuItem.Name = "выделенныйФайлToolStripMenuItem";
            this.выделенныйФайлToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.выделенныйФайлToolStripMenuItem.Text = "выделенный файл";
            this.выделенныйФайлToolStripMenuItem.Click += new System.EventHandler(this.ВыделенныйФайлToolStripMenuItem_Click);
            // 
            // всеФайлыToolStripMenuItem
            // 
            this.всеФайлыToolStripMenuItem.Name = "всеФайлыToolStripMenuItem";
            this.всеФайлыToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.всеФайлыToolStripMenuItem.Text = "все файлы";
            this.всеФайлыToolStripMenuItem.Click += new System.EventHandler(this.ВсеФайлыToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.ВыходToolStripMenuItem_Click);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.ОПрограммеToolStripMenuItem_Click);
            // 
            // Svet_files
            // 
            this.Svet_files.BackColor = System.Drawing.Color.Gainsboro;
            this.Svet_files.Location = new System.Drawing.Point(190, 85);
            this.Svet_files.Name = "Svet_files";
            this.Svet_files.Size = new System.Drawing.Size(215, 35);
            this.Svet_files.TabIndex = 2;
            this.Svet_files.Text = "Загрузить световой/световые файл(ы) (формат im2)";
            this.Svet_files.UseVisualStyleBackColor = false;
            this.Svet_files.Click += new System.EventHandler(this.Svet_files_Click);
            this.Svet_files.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.Svet_files.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // XML_file
            // 
            this.XML_file.BackColor = System.Drawing.Color.Gainsboro;
            this.XML_file.Location = new System.Drawing.Point(10, 85);
            this.XML_file.Name = "XML_file";
            this.XML_file.Size = new System.Drawing.Size(165, 35);
            this.XML_file.TabIndex = 3;
            this.XML_file.Text = "Загрузить текстовый файлы (формат xml)";
            this.XML_file.UseVisualStyleBackColor = false;
            this.XML_file.Click += new System.EventHandler(this.XML_file_Click);
            this.XML_file.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.XML_file.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // Temno_file
            // 
            this.Temno_file.BackColor = System.Drawing.Color.Gainsboro;
            this.Temno_file.Location = new System.Drawing.Point(10, 40);
            this.Temno_file.Name = "Temno_file";
            this.Temno_file.Size = new System.Drawing.Size(165, 35);
            this.Temno_file.TabIndex = 4;
            this.Temno_file.Text = "Загрузить темновой файл (формат im2)";
            this.Temno_file.UseVisualStyleBackColor = false;
            this.Temno_file.Click += new System.EventHandler(this.Temno_file_Click);
            this.Temno_file.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.Temno_file.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // Defect_file
            // 
            this.Defect_file.BackColor = System.Drawing.Color.Gainsboro;
            this.Defect_file.Location = new System.Drawing.Point(190, 40);
            this.Defect_file.Name = "Defect_file";
            this.Defect_file.Size = new System.Drawing.Size(215, 35);
            this.Defect_file.TabIndex = 5;
            this.Defect_file.Text = "Загрузить файл дефектных элементов (формат im2)";
            this.Defect_file.UseVisualStyleBackColor = false;
            this.Defect_file.Click += new System.EventHandler(this.Defect_file_Click);
            this.Defect_file.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.Defect_file.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // Adres_Temno_file
            // 
            this.Adres_Temno_file.AutoSize = true;
            this.Adres_Temno_file.Location = new System.Drawing.Point(10, 150);
            this.Adres_Temno_file.Name = "Adres_Temno_file";
            this.Adres_Temno_file.Size = new System.Drawing.Size(136, 13);
            this.Adres_Temno_file.TabIndex = 6;
            this.Adres_Temno_file.Text = "Путь к темновому файлу:";
            // 
            // Adres_Defect_file
            // 
            this.Adres_Defect_file.AutoSize = true;
            this.Adres_Defect_file.Location = new System.Drawing.Point(10, 200);
            this.Adres_Defect_file.Name = "Adres_Defect_file";
            this.Adres_Defect_file.Size = new System.Drawing.Size(194, 13);
            this.Adres_Defect_file.TabIndex = 7;
            this.Adres_Defect_file.Text = "Путь к файлу дефектных элементов:";
            // 
            // Adres_XML_file
            // 
            this.Adres_XML_file.AutoSize = true;
            this.Adres_XML_file.Location = new System.Drawing.Point(1120, 40);
            this.Adres_XML_file.Name = "Adres_XML_file";
            this.Adres_XML_file.Size = new System.Drawing.Size(139, 13);
            this.Adres_XML_file.TabIndex = 8;
            this.Adres_XML_file.Text = "Путь к текстовому файлу:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 260);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Путь к световым файлам:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1120, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(230, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Содержимое тектового файла (формат xml):";
            // 
            // TB_Temno_file
            // 
            this.TB_Temno_file.Location = new System.Drawing.Point(10, 170);
            this.TB_Temno_file.Name = "TB_Temno_file";
            this.TB_Temno_file.ReadOnly = true;
            this.TB_Temno_file.Size = new System.Drawing.Size(400, 20);
            this.TB_Temno_file.TabIndex = 11;
            // 
            // TB__Defect_file
            // 
            this.TB__Defect_file.Location = new System.Drawing.Point(10, 220);
            this.TB__Defect_file.Name = "TB__Defect_file";
            this.TB__Defect_file.ReadOnly = true;
            this.TB__Defect_file.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.TB__Defect_file.Size = new System.Drawing.Size(400, 20);
            this.TB__Defect_file.TabIndex = 12;
            // 
            // TB_XML_file
            // 
            this.TB_XML_file.Location = new System.Drawing.Point(1120, 60);
            this.TB_XML_file.Name = "TB_XML_file";
            this.TB_XML_file.ReadOnly = true;
            this.TB_XML_file.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.TB_XML_file.Size = new System.Drawing.Size(250, 20);
            this.TB_XML_file.TabIndex = 13;
            // 
            // LIST_svet_files
            // 
            this.LIST_svet_files.ContextMenuStrip = this.contextMenuStrip1;
            this.LIST_svet_files.FormattingEnabled = true;
            this.LIST_svet_files.HorizontalScrollbar = true;
            this.LIST_svet_files.Location = new System.Drawing.Point(10, 280);
            this.LIST_svet_files.Name = "LIST_svet_files";
            this.LIST_svet_files.Size = new System.Drawing.Size(165, 199);
            this.LIST_svet_files.TabIndex = 14;
            this.LIST_svet_files.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LIST_svet_files_MouseClick);
            this.LIST_svet_files.SelectedIndexChanged += new System.EventHandler(this.RB_show_CheckedChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.снятьВыделениеToolStripMenuItem,
            this.удалитьToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(170, 48);
            this.contextMenuStrip1.Text = "Удалить файл";
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // снятьВыделениеToolStripMenuItem
            // 
            this.снятьВыделениеToolStripMenuItem.Name = "снятьВыделениеToolStripMenuItem";
            this.снятьВыделениеToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.снятьВыделениеToolStripMenuItem.Text = "Снять выделение";
            this.снятьВыделениеToolStripMenuItem.Click += new System.EventHandler(this.снятьВыделениеToolStripMenuItem_Click);
            // 
            // удалитьToolStripMenuItem
            // 
            this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.удалитьToolStripMenuItem.Text = "Удалить";
            this.удалитьToolStripMenuItem.Click += new System.EventHandler(this.удалитьToolStripMenuItem_Click);
            // 
            // TB_XML_Description
            // 
            this.TB_XML_Description.Location = new System.Drawing.Point(1120, 120);
            this.TB_XML_Description.Multiline = true;
            this.TB_XML_Description.Name = "TB_XML_Description";
            this.TB_XML_Description.ReadOnly = true;
            this.TB_XML_Description.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.TB_XML_Description.Size = new System.Drawing.Size(250, 435);
            this.TB_XML_Description.TabIndex = 15;
            this.TB_XML_Description.TabStop = false;
            this.TB_XML_Description.Text = "Файл xml";
            // 
            // btn_srednee
            // 
            this.btn_srednee.BackColor = System.Drawing.Color.Gainsboro;
            this.btn_srednee.Location = new System.Drawing.Point(35, 520);
            this.btn_srednee.Name = "btn_srednee";
            this.btn_srednee.Size = new System.Drawing.Size(140, 40);
            this.btn_srednee.TabIndex = 16;
            this.btn_srednee.Text = "Усреднение по числу кадров";
            this.btn_srednee.UseVisualStyleBackColor = false;
            this.btn_srednee.Click += new System.EventHandler(this.btn_srednee_Click);
            this.btn_srednee.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.btn_srednee.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // openFileDialog_im2
            // 
            this.openFileDialog_im2.FileName = "Ошибка:";
            this.openFileDialog_im2.Filter = "im2 files|*.im2";
            // 
            // openFileDialog_xml
            // 
            this.openFileDialog_xml.FileName = "Ошибка:";
            this.openFileDialog_xml.Filter = "xml files|*.xml";
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.FileName = "Ошибка:";
            this.saveFileDialog.Filter = "im2 File|*.im2";
            // 
            // DeliteAll
            // 
            this.DeliteAll.Location = new System.Drawing.Point(310, 660);
            this.DeliteAll.Name = "DeliteAll";
            this.DeliteAll.Size = new System.Drawing.Size(70, 40);
            this.DeliteAll.TabIndex = 17;
            this.DeliteAll.Text = "Очистить поля";
            this.DeliteAll.UseVisualStyleBackColor = true;
            this.DeliteAll.Click += new System.EventHandler(this.DeliteAll_Click);
            this.DeliteAll.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.DeliteAll.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // Otobrajenie
            // 
            this.Otobrajenie.AutoSize = true;
            this.Otobrajenie.Location = new System.Drawing.Point(230, 510);
            this.Otobrajenie.Name = "Otobrajenie";
            this.Otobrajenie.Size = new System.Drawing.Size(150, 13);
            this.Otobrajenie.TabIndex = 18;
            this.Otobrajenie.Text = "Отображение изображения:";
            // 
            // RB_temno_show
            // 
            this.RB_temno_show.AutoSize = true;
            this.RB_temno_show.Location = new System.Drawing.Point(230, 530);
            this.RB_temno_show.Name = "RB_temno_show";
            this.RB_temno_show.Size = new System.Drawing.Size(134, 17);
            this.RB_temno_show.TabIndex = 19;
            this.RB_temno_show.TabStop = true;
            this.RB_temno_show.Text = "темнового исходного";
            this.RB_temno_show.UseVisualStyleBackColor = true;
            this.RB_temno_show.CheckedChanged += new System.EventHandler(this.RB_show_CheckedChanged);
            // 
            // RB_svet_clear_show
            // 
            this.RB_svet_clear_show.AutoSize = true;
            this.RB_svet_clear_show.Location = new System.Drawing.Point(230, 550);
            this.RB_svet_clear_show.Name = "RB_svet_clear_show";
            this.RB_svet_clear_show.Size = new System.Drawing.Size(132, 17);
            this.RB_svet_clear_show.TabIndex = 21;
            this.RB_svet_clear_show.TabStop = true;
            this.RB_svet_clear_show.Text = "светового исходного";
            this.RB_svet_clear_show.UseVisualStyleBackColor = true;
            this.RB_svet_clear_show.CheckedChanged += new System.EventHandler(this.RB_show_CheckedChanged);
            // 
            // Delite1
            // 
            this.Delite1.Location = new System.Drawing.Point(210, 655);
            this.Delite1.Name = "Delite1";
            this.Delite1.Size = new System.Drawing.Size(90, 50);
            this.Delite1.TabIndex = 22;
            this.Delite1.Text = "Удалить выбранный файл";
            this.Delite1.UseVisualStyleBackColor = true;
            this.Delite1.Click += new System.EventHandler(this.Delite1_Click);
            this.Delite1.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.Delite1.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // pictureBoxkadr
            // 
            this.pictureBoxkadr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxkadr.Cursor = System.Windows.Forms.Cursors.Cross;
            this.pictureBoxkadr.Image = global::IPO_PRO.Properties.Resources.BackImage;
            this.pictureBoxkadr.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxkadr.Name = "pictureBoxkadr";
            this.pictureBoxkadr.Size = new System.Drawing.Size(800, 600);
            this.pictureBoxkadr.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxkadr.TabIndex = 23;
            this.pictureBoxkadr.TabStop = false;
            this.pictureBoxkadr.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBoxKadr_MouseClick);
            this.pictureBoxkadr.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBoxKadr_MouseDown);
            this.pictureBoxkadr.MouseLeave += new System.EventHandler(this.pictureBoxkadr_MouseLeave);
            this.pictureBoxkadr.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBoxkadr_MouseMove);
            this.pictureBoxkadr.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBoxkadr_MouseUp);
            // 
            // tableLayoutPanel
            // 
            this.tableLayoutPanel.AutoScroll = true;
            this.tableLayoutPanel.AutoSize = true;
            this.tableLayoutPanel.ColumnCount = 2;
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel.Controls.Add(this.TB_Report, 1, 1);
            this.tableLayoutPanel.Controls.Add(this.chartSTB, 1, 0);
            this.tableLayoutPanel.Controls.Add(this.chartSTR, 0, 1);
            this.tableLayoutPanel.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel.Name = "tableLayoutPanel";
            this.tableLayoutPanel.RowCount = 2;
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel.Size = new System.Drawing.Size(1080, 812);
            this.tableLayoutPanel.TabIndex = 24;
            // 
            // TB_Report
            // 
            this.TB_Report.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TB_Report.Location = new System.Drawing.Point(813, 612);
            this.TB_Report.Multiline = true;
            this.TB_Report.Name = "TB_Report";
            this.TB_Report.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.TB_Report.Size = new System.Drawing.Size(264, 197);
            this.TB_Report.TabIndex = 1;
            // 
            // chartSTB
            // 
            chartArea1.AlignmentStyle = ((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentStyles)((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentStyles.Position | System.Windows.Forms.DataVisualization.Charting.AreaAlignmentStyles.PlotPosition)));
            chartArea1.Name = "ChartArea1";
            chartArea1.Position.Auto = false;
            chartArea1.Position.Height = 100F;
            chartArea1.Position.Width = 100F;
            this.chartSTB.ChartAreas.Add(chartArea1);
            this.chartSTB.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.Enabled = false;
            legend1.Name = "Legend1";
            this.chartSTB.Legends.Add(legend1);
            this.chartSTB.Location = new System.Drawing.Point(813, 3);
            this.chartSTB.Name = "chartSTB";
            series1.BorderWidth = 2;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Color = System.Drawing.Color.Blue;
            series1.Legend = "Legend1";
            series1.Name = "ChartTemnoSTB";
            series2.BorderWidth = 2;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Color = System.Drawing.Color.Red;
            series2.Legend = "Legend1";
            series2.Name = "ChartSvetSTB";
            this.chartSTB.Series.Add(series1);
            this.chartSTB.Series.Add(series2);
            this.chartSTB.Size = new System.Drawing.Size(264, 603);
            this.chartSTB.TabIndex = 2;
            this.chartSTB.Text = "chartSTB";
            // 
            // chartSTR
            // 
            chartArea2.AlignmentStyle = ((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentStyles)((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentStyles.Position | System.Windows.Forms.DataVisualization.Charting.AreaAlignmentStyles.PlotPosition)));
            chartArea2.Name = "ChartArea1";
            chartArea2.Position.Auto = false;
            chartArea2.Position.Height = 100F;
            chartArea2.Position.Width = 100F;
            this.chartSTR.ChartAreas.Add(chartArea2);
            this.chartSTR.Dock = System.Windows.Forms.DockStyle.Fill;
            legend2.Enabled = false;
            legend2.Name = "Legend1";
            this.chartSTR.Legends.Add(legend2);
            this.chartSTR.Location = new System.Drawing.Point(3, 612);
            this.chartSTR.Name = "chartSTR";
            series3.BorderWidth = 2;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Color = System.Drawing.Color.Blue;
            series3.Legend = "Legend1";
            series3.Name = "ChartTemnoSTR";
            series4.BorderWidth = 3;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Color = System.Drawing.Color.Red;
            series4.Legend = "Legend1";
            series4.Name = "ChartSvetSTR";
            this.chartSTR.Series.Add(series3);
            this.chartSTR.Series.Add(series4);
            this.chartSTR.Size = new System.Drawing.Size(804, 197);
            this.chartSTR.TabIndex = 3;
            this.chartSTR.Text = "chartSTR";
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.Controls.Add(this.pictureBoxkadr);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(804, 603);
            this.panel1.TabIndex = 43;
            // 
            // btn_correcttemno
            // 
            this.btn_correcttemno.Location = new System.Drawing.Point(35, 580);
            this.btn_correcttemno.Name = "btn_correcttemno";
            this.btn_correcttemno.Size = new System.Drawing.Size(140, 40);
            this.btn_correcttemno.TabIndex = 28;
            this.btn_correcttemno.Text = "Коррекция темнового сигнала";
            this.btn_correcttemno.UseVisualStyleBackColor = true;
            this.btn_correcttemno.Click += new System.EventHandler(this.Btn_correcttemno_Click);
            this.btn_correcttemno.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.btn_correcttemno.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // btn_correctdefect
            // 
            this.btn_correctdefect.Location = new System.Drawing.Point(35, 640);
            this.btn_correctdefect.Name = "btn_correctdefect";
            this.btn_correctdefect.Size = new System.Drawing.Size(140, 40);
            this.btn_correctdefect.TabIndex = 29;
            this.btn_correctdefect.Text = "Коррекция дефектных элементов";
            this.btn_correctdefect.UseVisualStyleBackColor = true;
            this.btn_correctdefect.Click += new System.EventHandler(this.Btn_correctdefect_Click);
            this.btn_correctdefect.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.btn_correctdefect.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // KadrCount
            // 
            this.KadrCount.AutoSize = true;
            this.KadrCount.Location = new System.Drawing.Point(440, 655);
            this.KadrCount.Name = "KadrCount";
            this.KadrCount.Size = new System.Drawing.Size(77, 13);
            this.KadrCount.TabIndex = 30;
            this.KadrCount.Text = "Номер кадра:";
            // 
            // TrackBarKadr
            // 
            this.TrackBarKadr.Enabled = false;
            this.TrackBarKadr.Location = new System.Drawing.Point(430, 685);
            this.TrackBarKadr.Minimum = 1;
            this.TrackBarKadr.Name = "TrackBarKadr";
            this.TrackBarKadr.Size = new System.Drawing.Size(672, 45);
            this.TrackBarKadr.TabIndex = 31;
            this.TrackBarKadr.Value = 1;
            this.TrackBarKadr.Scroll += new System.EventHandler(this.TrackBarKadr_Scroll_1);
            // 
            // ProgressBar
            // 
            this.ProgressBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ProgressBar.Location = new System.Drawing.Point(0, 740);
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.Size = new System.Drawing.Size(1384, 22);
            this.ProgressBar.TabIndex = 32;
            this.ProgressBar.Visible = false;
            // 
            // RB_svet_temno_show
            // 
            this.RB_svet_temno_show.AutoSize = true;
            this.RB_svet_temno_show.Location = new System.Drawing.Point(230, 570);
            this.RB_svet_temno_show.Name = "RB_svet_temno_show";
            this.RB_svet_temno_show.Size = new System.Drawing.Size(155, 17);
            this.RB_svet_temno_show.TabIndex = 33;
            this.RB_svet_temno_show.TabStop = true;
            this.RB_svet_temno_show.Text = "светового без темнового";
            this.RB_svet_temno_show.UseVisualStyleBackColor = true;
            // 
            // RB_svet_def_show
            // 
            this.RB_svet_def_show.AutoSize = true;
            this.RB_svet_def_show.Location = new System.Drawing.Point(230, 590);
            this.RB_svet_def_show.Name = "RB_svet_def_show";
            this.RB_svet_def_show.Size = new System.Drawing.Size(150, 17);
            this.RB_svet_def_show.TabIndex = 34;
            this.RB_svet_def_show.TabStop = true;
            this.RB_svet_def_show.Text = "светового без дефектов";
            this.RB_svet_def_show.UseVisualStyleBackColor = true;
            // 
            // btn_delKadr
            // 
            this.btn_delKadr.Location = new System.Drawing.Point(925, 650);
            this.btn_delKadr.Name = "btn_delKadr";
            this.btn_delKadr.Size = new System.Drawing.Size(161, 23);
            this.btn_delKadr.TabIndex = 35;
            this.btn_delKadr.Text = "Удалить кадр";
            this.btn_delKadr.UseVisualStyleBackColor = true;
            this.btn_delKadr.Click += new System.EventHandler(this.Btn_delKadr_Click);
            this.btn_delKadr.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            this.btn_delKadr.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // lbx_delKadr
            // 
            this.lbx_delKadr.ContextMenuStrip = this.contextMenuStrip2;
            this.lbx_delKadr.FormattingEnabled = true;
            this.lbx_delKadr.Location = new System.Drawing.Point(1120, 600);
            this.lbx_delKadr.Name = "lbx_delKadr";
            this.lbx_delKadr.Size = new System.Drawing.Size(250, 108);
            this.lbx_delKadr.TabIndex = 36;
            this.lbx_delKadr.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lbx_delKadr_MouseClick);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.снятьВыделениеToolStripMenuItem1,
            this.удалитьToolStripMenuItem1});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(170, 48);
            this.contextMenuStrip2.Text = "Удалить файл";
            // 
            // снятьВыделениеToolStripMenuItem1
            // 
            this.снятьВыделениеToolStripMenuItem1.Name = "снятьВыделениеToolStripMenuItem1";
            this.снятьВыделениеToolStripMenuItem1.Size = new System.Drawing.Size(169, 22);
            this.снятьВыделениеToolStripMenuItem1.Text = "Снять выделение";
            this.снятьВыделениеToolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // удалитьToolStripMenuItem1
            // 
            this.удалитьToolStripMenuItem1.Name = "удалитьToolStripMenuItem1";
            this.удалитьToolStripMenuItem1.Size = new System.Drawing.Size(169, 22);
            this.удалитьToolStripMenuItem1.Text = "Удалить";
            this.удалитьToolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // label_del_kadr
            // 
            this.label_del_kadr.AutoSize = true;
            this.label_del_kadr.Location = new System.Drawing.Point(1120, 580);
            this.label_del_kadr.Name = "label_del_kadr";
            this.label_del_kadr.Size = new System.Drawing.Size(146, 13);
            this.label_del_kadr.TabIndex = 37;
            this.label_del_kadr.Text = "Номера удаленных кадров:";
            // 
            // l_XML_Description
            // 
            this.l_XML_Description.AutoSize = true;
            this.l_XML_Description.Location = new System.Drawing.Point(1120, 100);
            this.l_XML_Description.Name = "l_XML_Description";
            this.l_XML_Description.Size = new System.Drawing.Size(186, 13);
            this.l_XML_Description.TabIndex = 38;
            this.l_XML_Description.Text = "Служебная информация (xml файл):";
            // 
            // openFileDialog_txt
            // 
            this.openFileDialog_txt.FileName = "openFileDialog_txt";
            this.openFileDialog_txt.Filter = "txt Files|*.txt";
            // 
            // KadrNumber
            // 
            this.KadrNumber.Location = new System.Drawing.Point(525, 653);
            this.KadrNumber.Name = "KadrNumber";
            this.KadrNumber.ReadOnly = true;
            this.KadrNumber.Size = new System.Drawing.Size(50, 20);
            this.KadrNumber.TabIndex = 39;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.tableLayoutPanel);
            this.panel2.Location = new System.Drawing.Point(425, 40);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(680, 600);
            this.panel2.TabIndex = 40;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(210, 280);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(185, 199);
            this.listBox1.TabIndex = 41;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1384, 762);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.KadrNumber);
            this.Controls.Add(this.l_XML_Description);
            this.Controls.Add(this.label_del_kadr);
            this.Controls.Add(this.lbx_delKadr);
            this.Controls.Add(this.btn_delKadr);
            this.Controls.Add(this.RB_svet_def_show);
            this.Controls.Add(this.RB_svet_temno_show);
            this.Controls.Add(this.ProgressBar);
            this.Controls.Add(this.TrackBarKadr);
            this.Controls.Add(this.KadrCount);
            this.Controls.Add(this.btn_correctdefect);
            this.Controls.Add(this.btn_correcttemno);
            this.Controls.Add(this.Delite1);
            this.Controls.Add(this.RB_svet_clear_show);
            this.Controls.Add(this.RB_temno_show);
            this.Controls.Add(this.Otobrajenie);
            this.Controls.Add(this.DeliteAll);
            this.Controls.Add(this.btn_srednee);
            this.Controls.Add(this.TB_XML_Description);
            this.Controls.Add(this.LIST_svet_files);
            this.Controls.Add(this.TB_XML_file);
            this.Controls.Add(this.TB__Defect_file);
            this.Controls.Add(this.TB_Temno_file);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Adres_XML_file);
            this.Controls.Add(this.Adres_Defect_file);
            this.Controls.Add(this.Adres_Temno_file);
            this.Controls.Add(this.Defect_file);
            this.Controls.Add(this.Temno_file);
            this.Controls.Add(this.XML_file);
            this.Controls.Add(this.Svet_files);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Визуализатор и корректор: файл(ы) формата im2";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxkadr)).EndInit();
            this.tableLayoutPanel.ResumeLayout(false);
            this.tableLayoutPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartSTB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartSTR)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TrackBarKadr)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem расчитатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ОчиститьполяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.Button Svet_files;
        private System.Windows.Forms.Button XML_file;
        private System.Windows.Forms.Button Temno_file;
        private System.Windows.Forms.Button Defect_file;
        private System.Windows.Forms.Label Adres_Temno_file;
        private System.Windows.Forms.Label Adres_Defect_file;
        private System.Windows.Forms.Label Adres_XML_file;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TB_Temno_file;
        private System.Windows.Forms.TextBox TB__Defect_file;
        private System.Windows.Forms.TextBox TB_XML_file;
        private System.Windows.Forms.ListBox LIST_svet_files;
        private System.Windows.Forms.TextBox TB_XML_Description;
        private System.Windows.Forms.Button btn_srednee;
        private System.Windows.Forms.OpenFileDialog openFileDialog_im2;
        private System.Windows.Forms.OpenFileDialog openFileDialog_xml;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.ToolStripMenuItem темноаойФайлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem фактДефектныхЭлементныхToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem текстовыйФайлXmlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem световойсветовыеФайлыToolStripMenuItem;
        private System.Windows.Forms.Button DeliteAll;
        private System.Windows.Forms.Label Otobrajenie;
        private System.Windows.Forms.RadioButton RB_temno_show;
        private System.Windows.Forms.RadioButton RB_svet_clear_show;
        private System.Windows.Forms.Button Delite1;
        private System.Windows.Forms.PictureBox pictureBoxkadr;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private System.Windows.Forms.TextBox TB_Report;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartSTB;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartSTR;
        private System.Windows.Forms.ToolStripMenuItem выделенныйФайлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem всеФайлыToolStripMenuItem;
        private System.Windows.Forms.Button btn_correcttemno;
        private System.Windows.Forms.Button btn_correctdefect;
        private System.Windows.Forms.ToolStripMenuItem усреднениеПоЧислуКадровToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem коррекцияТемновогоСигналаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem коррекцияДефектныхЭлементовToolStripMenuItem;
        private System.Windows.Forms.Label KadrCount;
        private System.Windows.Forms.TrackBar TrackBarKadr;
        public System.Windows.Forms.ProgressBar ProgressBar;
        private System.Windows.Forms.RadioButton RB_svet_temno_show;
        private System.Windows.Forms.RadioButton RB_svet_def_show;
        private System.Windows.Forms.Button btn_delKadr;
        private System.Windows.Forms.ListBox lbx_delKadr;
        private System.Windows.Forms.Label label_del_kadr;
        private System.Windows.Forms.Label l_XML_Description;
        private System.Windows.Forms.OpenFileDialog openFileDialog_txt;
        private System.Windows.Forms.TextBox KadrNumber;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem снятьВыделениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem снятьВыделениеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListBox listBox1;
    }
}

