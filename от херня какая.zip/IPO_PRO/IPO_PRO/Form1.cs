﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace IPO_PRO
{
    public partial class Form1 : Form
    {
        /* В начале программы
         *      мы объявляем 
         *          все параметры
         *              и даже форму (о программе)!
         */
        // Параметры:
        string temno_file;
        string xml_file;
        string xml_file_Description;
        string defect_file;
        string[] svet_files;
        int[,] temno_kadr;
        int[,] svet_kadr;
        int w, h;
        // Форма (о программе):
        About about;
        List<List<Point[]>> defect;
        List<List<int>> deleteKadr; // Список на удаляемые световые файлы
        List<int> deleteTemnoKadr; // Список удалемых кадров из темнового файла
        Pen zoomBorder;
        ForZoom zoom;


        /* Отсюда пошла
         *      основная форма
         *          нашей программы,
         *              которая идет до
         *                  самого конца!
         */
        public Form1()
        {
            InitializeComponent();
            zoomBorder = new Pen(Color.Green);
            deleteKadr = new List<List<int>>();
            zoom = new ForZoom();
            zoom.zoom = false;
        }

        #region About
        /* Информация о программе!
         */
        private void ОПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            about = new About(this);
            about.Show();
        }
        public void closeabout()
        {
            about = null;
        }
        #endregion

        #region Load
        /* Загрузка файлов!
         */
        // Работаем с темновым файлом:
        private void Temno_file_Click(object sender, EventArgs e)
        {
            openFileDialog_im2.Multiselect = false;
            if (openFileDialog_im2.ShowDialog() == DialogResult.OK)
            {
                temno_file = openFileDialog_im2.FileName;
                TB_Temno_file.Text = temno_file;
                temno_kadr = LoadFile(temno_file, false, !string.IsNullOrEmpty(defect_file));
                deleteTemnoKadr = new List<int>();
            }
        }
        private void ТемноаойФайлToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Temno_file_Click(this, new EventArgs());
        }
        // Работаем с дефектным файлом:
        private void Defect_file_Click(object sender, EventArgs e)
        {
            if (openFileDialog_txt.ShowDialog() == DialogResult.OK)
            {
                defect_file = openFileDialog_txt.FileName;
                TB__Defect_file.Text = defect_file;
                using (StreamReader reader = File.OpenText(defect_file))
                {
                    defect = new List<List<Point[]>>();
                    defect.Add(new List<Point[]>()); defect.Add(new List<Point[]>()); defect.Add(new List<Point[]>());
                    while (!reader.EndOfStream)
                    {
                        string[] str = reader.ReadLine().Split(','); //по идее всегда должен давать string[2 или 4]
                        if (str.Length == 2) //Если только 2 числа, значит указан пиксель
                            defect[0].Add(new Point[2] { new Point(int.Parse(str[0]) - 1, int.Parse(str[1]) - 1), Point.Empty });
                        else
                        if (String.IsNullOrEmpty(str[0])) //указали дефектную строку
                            defect[2].Add(new Point[2] { new Point(-1, int.Parse(str[1]) - 1), new Point(int.Parse(str[2]) - 1, int.Parse(str[3]) - 1) });
                        else //или столбец
                            defect[1].Add(new Point[2] { new Point(int.Parse(str[0]) - 1, -1), new Point(int.Parse(str[2]) - 1, int.Parse(str[3]) - 1) });
                    }
                }
            }
        }
        private void ФайлДефектныхЭлементовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Defect_file_Click(this, new EventArgs());
        }
        // Работаем с xml файлом:
        private void XML_file_Click(object sender, EventArgs e)
        {
            openFileDialog_xml.Multiselect = false;
            if (openFileDialog_xml.ShowDialog() == DialogResult.OK)
            {
                xml_file = openFileDialog_xml.FileName;
                xml_file_Description = File.ReadAllText(xml_file);
            }
            TB_XML_file.Text = xml_file;
            TB_XML_Description.Text = xml_file_Description;
        }
        private void ТекстовыйФайлXmlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XML_file_Click(this, new EventArgs());
        }
        // Работаем с световым/световыми файлом(ами):
        private void Svet_files_Click(object sender, EventArgs e)
        {
            openFileDialog_im2.Multiselect = true;
            if (openFileDialog_im2.ShowDialog() == DialogResult.OK) svet_files = openFileDialog_im2.FileNames;
            LIST_svet_files.Items.Clear();
            LIST_svet_files.Items.AddRange(svet_files);
            foreach (string s in svet_files) deleteKadr.Add(new List<int>());
        }
        private void СветовойсветовыеФайлыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Svet_files_Click(this, new EventArgs());
        }
        #endregion

        #region Convert
        /* Обработка загруженных файлов:
         */
        private void btn_srednee_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            run();
            this.Enabled = true;
        }
        private void УсреднениеПоЧислуКадровToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btn_srednee_Click(this, new EventArgs());
        }
        private void Btn_correcttemno_Click(object sender, EventArgs e)
        {
            try
            {
                this.Enabled = false;
                ProgressBar.Maximum = LIST_svet_files.Items.Count;
                ProgressBar.Value = 0;
                ProgressBar.Step = 1;
                ProgressBar.Visible = true;
                //проверочка
                if (string.IsNullOrEmpty(temno_file) || svet_files == null || svet_files.Count() == 0)
                    throw new ArgumentException("Не все файлы найдены! Загрузите темновые и/или световые файл(ы) и снова нажмите кнопку \"ОБработать\"");
                w = 0; h = 0; //обнуляем
                string newFile = Path.GetFileNameWithoutExtension(temno_file) + "_sr.im2";
                newFile = Path.Combine(Path.GetDirectoryName(temno_file), newFile); //путь до нового файла
                SaveFile(newFile, LoadFile(temno_file));
                foreach (string file in svet_files)
                { //по каждому файлу
                    newFile = Path.GetFileNameWithoutExtension(file) + "_kor.im2";
                    newFile = Path.Combine(Path.GetDirectoryName(file), newFile); //путь до нового файла
                    SaveFile(newFile, LoadFile(file, true, false));
                    ProgressBar.PerformStep();
                }
                this.Enabled = true;
                ProgressBar.Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка обработки", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                MessageBox.Show("Обработка завершена!");
            }
        }
        private void КоррекцияТемновогоСигналаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Btn_correcttemno_Click(this, new EventArgs());
        }
        private void Btn_correctdefect_Click(object sender, EventArgs e)
        {
            try
            {
                this.Enabled = false;
                ProgressBar.Maximum = LIST_svet_files.Items.Count;
                ProgressBar.Value = 0;
                ProgressBar.Step = 1;
                ProgressBar.Visible = true;
                //проверочка
                if (string.IsNullOrEmpty(temno_file) || svet_files == null || svet_files.Count() == 0)
                    throw new ArgumentException("Не все файлы найдены! Загрузите темновые и/или световые файл(ы) и снова нажмите кнопку \"ОБработать\"");
                w = 0; h = 0; //обнуляем
                string newFile = Path.GetFileNameWithoutExtension(temno_file) + "_sr.im2";
                newFile = Path.GetFileNameWithoutExtension(temno_file) + "_kordef.im2";
                newFile = Path.Combine(Path.GetDirectoryName(temno_file), newFile); //путь до нового файла
                SaveFile(newFile, LoadFile(temno_file, false, true));
                foreach (string file in svet_files)
                { //по каждому файлу
                    newFile = Path.GetFileNameWithoutExtension(file) + "_kordef.im2";
                    newFile = Path.Combine(Path.GetDirectoryName(file), newFile); //путь до нового файла
                    SaveFile(newFile, LoadFile(file, true, true));
                    ProgressBar.PerformStep();
                }
                this.Enabled = true;
                ProgressBar.Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка обработки", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                MessageBox.Show("Обработка завершена!");
            }
        }
        private void КоррекцияДефектныхЭлементовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Btn_correctdefect_Click(this, new EventArgs());
        }
        #endregion

        #region Delete
        /* Очистка загруженных файлов:
         */
        private void Delite1_Click(object sender, EventArgs e)
        {
            if (LIST_svet_files.SelectedIndex == -1) return;
            LIST_svet_files.Items.Remove(LIST_svet_files.SelectedItem);
        }
        private void ВыделенныйФайлToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Delite1_Click(this, new EventArgs());
        }
        private void DeliteAll_Click(object sender, EventArgs e)
        {
            TB_Temno_file.Text = "";
            TB__Defect_file.Text = "";
            TB_XML_file.Text = "";
            TB_XML_Description.Text = "";
            LIST_svet_files.Items.Clear();
            lbx_delKadr.Items.Clear();
            RB_temno_show.Checked = false;
            RB_svet_clear_show.Checked = false;
            RB_svet_def_show.Checked = false;
            RB_svet_temno_show.Checked = false;
            TrackBarKadr.Value = 1;
            TrackBarKadr.Maximum = 1;
            KadrNumber.Text = "";
            TrackBarKadr.Enabled = false;
            pictureBoxkadr.Image = BackgroundImage;
        }
        private void ВсеФайлыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeliteAll_Click(this, new EventArgs());
        }
        private void Btn_delKadr_Click(object sender, EventArgs e)
        {
            if (RB_temno_show.Checked) deleteTemnoKadr.Add(TrackBarKadr.Value);
            else if (LIST_svet_files.SelectedIndex != -1) deleteKadr[LIST_svet_files.SelectedIndex].Add(TrackBarKadr.Value);
        }
        #endregion

        #region Exit
        /* Выход из программы:
         */
        private void ВыходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #endregion

        /* Все методы, которые 
         *      мы используем в 
         *          нашей программе!
         */
        // Метод загрузки всего содержимого файлов во внутренний код:
        public int[,] LoadFile(string _file, bool temno = false, bool dfk = false)
        {
            int[,] kadr;
            using (BinaryReader reader = new BinaryReader(File.Open(_file, FileMode.Open)))
            {
                reader.BaseStream.Position = 500;
                int ww = reader.ReadUInt16(); int hh = reader.ReadUInt16(); // (<--- тут) Читаем размеры.


                listBox1.Items.Add(ww);  // временно проверяем
                listBox1.Items.Add(hh);  // временно проверяем


                if (w == 0 || h == 0)
                { // Если размеры еще не распарсены, то парсим их:
                    w = ww;
                    h = hh;
                }
                // Проверки:
                if (ww != w || hh != h) throw new FileLoadException("Размер кадра в файле \"" + _file + "\" отличается от иных файлов");
                if (((reader.BaseStream.Length - 512) / (w * h * 2.0) % 1) != 0.0) throw new FileLoadException("Файл \"" + _file + "\" поврежден!");
                kadr = new int[w, h];
                int kadri = (int)((reader.BaseStream.Length - 512) / (w * h * 2)); // (<--- тут) Вычисляем количество кадров.
                reader.BaseStream.Position = 512; // Приступаем к чтению:
                for (int k = 0; k < kadri; k++)
                {
                    if (temno_kadr != null && _file == temno_file && deleteTemnoKadr.Contains(kadri + 1)) continue; // (<--- тут) Пропускаем если темновой и есть удаляемый кадр.
                    byte[] arr = reader.ReadBytes(w * h * 2); // Читаем сразу весь кусок:
                    for (int j = 0; j < w; j++)
                        for (int i = 0; i < h; i++)
                        {
                            int p = BitConverter.ToInt16(arr, (i * h + j) * 2);// (<--- тут) Парсим массив в памяти, суммируем кадры.
                            if (temno && temno_kadr != null)
                            {
                                p -= temno_kadr[j, i];
                                p = p < 0 ? 0 : p;
                            }
                            kadr[j, i] += p;
                        }
                }
                if (!string.IsNullOrEmpty(temno_file) && deleteTemnoKadr != null && _file == temno_file)
                {
                    kadri -= deleteTemnoKadr.Count(); // (<--- тут) Если темновой, вычитаем из кадров количество удаляемых кадров, мы же их пропустили.
                }
                if (svet_files != null && svet_files.Contains(_file))
                {
                    kadri -= deleteKadr[Array.IndexOf(svet_files, _file)].Count(); // (<--- тут) Если файл содержится в световых, то же самое.
                }
                for (int j = 0; j < w; j++)
                    for (int i = 0; i < h; i++)
                    {
                        kadr[j, i] /= kadri; // (<--- тут) Вычисляем средний кадр.
                    }
            }
            if (dfk && defect != null)
            {
                foreach (Point[] p in defect[0]) // Корректируем пиксели:
                { 
                    int pix = 0; int col = 0; // Если пиксел на краю кадра, то вычисляем среднее от реальных соседей:
                    if (p[0].X != 0)
                    {
                        pix += kadr[p[0].X - 1, p[0].Y]; col++; 
                    }     
                    if (p[0].X != w - 1)
                    {
                        pix += kadr[p[0].X + 1, p[0].Y]; col++;
                    }
                    if (p[0].Y != 0)
                    {
                        pix += kadr[p[0].X, p[0].Y - 1]; col++;
                    }
                    if (p[0].Y != h - 1)
                    {
                        pix += kadr[p[0].X, p[0].Y + 1]; col++;
                    }
                    kadr[p[0].X, p[0].Y] = pix / col;
                }
                foreach (Point[] p in defect[1]) // Корректируем столбцы:
                { 
                    for (int i = p[1].X; i <= p[1].Y; i++)
                    {
                        kadr[p[0].X, i] = (kadr[p[0].X + 1, i] + kadr[p[0].X - 1, i]) / 2;
                    }
                }
                foreach (Point[] p in defect[2]) // Корректируем строки:
                { 
                    for (int j = p[1].X; j <= p[1].Y; j++)
                    {
                    kadr[j, p[0].Y] = (kadr[j, p[0].Y + 1] + kadr[j, p[0].Y - 1]) / 2;
                    }
                }
            }
            return kadr;
        }
        // Метод загрузки кадра:
        public int[,] LoadKadr(string _file, int k = 1, bool temno = false, bool dfk = false)
        {
            int[,] kadr;
            using (BinaryReader reader = new BinaryReader(File.Open(_file, FileMode.Open)))
            {
                reader.BaseStream.Position = 500;
                int ww = reader.ReadUInt16(); int hh = reader.ReadUInt16(); // Читаем размеры:
                if (w == 0 || h == 0)
                { // Если размеры еще не распарсены, то парсим их:
                    w = ww;
                    h = hh;
                }
                // Проверки:
                if (ww != w || hh != h) throw new FileLoadException("Размер кадра в файле \"" + _file + "\" отличается от иных файлов");
                if (((reader.BaseStream.Length - 512.0) / (w * h * 2.0) % 1) != 0.0) throw new FileLoadException("Файл \"" + _file + "\" поврежден!");
                kadr = new int[w, h];
                int kadri = (int)((reader.BaseStream.Length - 512) / (w * h * 2)); // (<--- тут) Вычисляем количество кадров.
                reader.BaseStream.Position = 512 + (w * h * 2 * (k - 1)); // Приступаем к чтению:
                byte[] arr = reader.ReadBytes(w * h * 2); // Читаем сразу весь кусок
                int cur = 0;
                for (int i = 0; i < h; i++)
                    for (int j = 0; j < w; j++)
                    {
                        int p = BitConverter.ToUInt16(arr, cur);// Парсим массив в памяти, суммируем кадры:
                        if (temno && temno_kadr != null)
                        {
                            p -= temno_kadr[j, i];
                            p = p < 0 ? 0 : p;
                        }
                        kadr[j, i] += p;
                        cur += 2;
                    }
            }
            if (dfk && defect != null)
            {
                foreach (Point[] p in defect[0]) // Корректируем пиксели:
                { 
                    int pix = 0; int col = 0; // Если пиксел на краю кадра, то вычисляем среднее от реальных соседей:
                    if (p[0].X != 0)
                    {
                        pix += kadr[p[0].X - 1, p[0].Y]; col++;
                    }
                    if (p[0].X != w - 1)
                    {
                        pix += kadr[p[0].X + 1, p[0].Y]; col++;
                    }
                    if (p[0].Y != 0)
                    {
                        pix += kadr[p[0].X, p[0].Y - 1]; col++;
                    }
                    if (p[0].Y != h - 1)
                    {
                        pix += kadr[p[0].X, p[0].Y + 1]; col++;
                    }
                    kadr[p[0].X, p[0].Y] = pix / col;
                }
                foreach (Point[] p in defect[1]) // Корректируем столбцы:
                { 
                    for (int i = p[1].X; i <= p[1].Y; i++) kadr[p[0].X, i] = (kadr[p[0].X + 1, i] + kadr[p[0].X - 1, i]) / 2;
                }
                foreach (Point[] p in defect[2]) // Корректируем строки:
                { 
                    for (int j = p[1].X; j <= p[1].Y; j++) kadr[j, p[0].Y] = (kadr[j, p[0].Y + 1] + kadr[j, p[0].Y - 1]) / 2;
                }
            }
            return kadr;
        }
        // Метод получения количества кадров из загруженного файла:
        public int GetKadrCount(string _file)
        {
            int kadri = 0;
            using (BinaryReader reader = new BinaryReader(File.Open(_file, FileMode.Open)))
            {
                kadri = (int)((reader.BaseStream.Length - 512) / (w * h * 2)); // (<--- тут) Вычисляем количество кадров.
            }
            return kadri;
        }
        // Метод обработки всего содержимого загруженных во внутренний код файлов + создание усредненных световых и темновых файлов:
        private void run(bool _def = false)                                                                                                                                                                                                                                                                                                                                                                                         //ай маладца, таки докрутил сюда?) ну удаляй этот прикольчик )))
        {
            try
            {
                ProgressBar.Maximum = LIST_svet_files.Items.Count;
                ProgressBar.Value = 0;
                ProgressBar.Step = 1;
                ProgressBar.Visible = true;
                // Проверка для усредненных световых файлов:
                if (string.IsNullOrEmpty(temno_file) || svet_files == null || svet_files.Count() == 0)
                    throw new ArgumentException("Не все файлы найдены! Загрузите темновые и/или световые файл(ы) и снова нажмите кнопку \"ОБработать\"");
                w = 0; h = 0; // (<--- тут) Обнуляем.
                string newFile = Path.GetFileNameWithoutExtension(temno_file) + "_sr.im2";
                newFile = Path.Combine(Path.GetDirectoryName(temno_file), newFile); //путь до нового файла
                SaveFile(newFile, LoadFile(temno_file));
                SaveFile(newFile, LoadFile(temno_file, false, true));
                foreach (string file in svet_files)
                { //по каждому файлу
                    newFile = Path.GetFileNameWithoutExtension(file) + "_sr.im2";
                    newFile = Path.Combine(Path.GetDirectoryName(file), newFile); //путь до нового файла
                    ProgressBar.PerformStep();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка обработки", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ProgressBar.Visible = false;
            }
        }
        // Метод сохранения файлов:
        private void SaveFile(string newFile, int[,] kadr)
        {
            using (BinaryWriter writer = new BinaryWriter(File.Create(newFile)))
            {
                byte[] head = new byte[512];
                for (int i = 0; i < 512; i++)
                {// Пишем данные:
                    if (i == 500)
                    {
                        byte[] W = BitConverter.GetBytes((short)w);
                        //Array.Reverse(W);
                        byte[] H = BitConverter.GetBytes((short)h);
                        //Array.Reverse(H);
                        head[i] = W[0]; head[i + 1] = W[1]; head[i + 2] = H[0]; head[i + 3] = H[1];
                        i += 4; // Уже выше (вот только) записали 4 байта...
                    }
                    else head[i] = (byte)32;
                }
                writer.Write(head); // (<--- тут) Пишем шапку.
                head = new byte[w * h * 2]; // Готовим кадр:
                using (MemoryStream stream = new MemoryStream(head))
                {
                    for (int j = 0; j < w; j++)
                        for (int i = 0; i < h; i++) stream.Write(BitConverter.GetBytes((ushort)kadr[j, i]), 0, 2);
                }
                writer.Write(head); // (<--- тут) Пишем кадр одним куском.
            }
        }
        // Метод предобработки для реализации метода визуализации загруженных файлов:
        public Bitmap ConvertArrayToBtm(int[,] _array)
        {
            Bitmap temp = new Bitmap(_array.GetLength(0), _array.GetLength(1)); // (<--- тут) Новый битмап по размеру массива.
            int min = _array.Cast<int>().Min(); // (LINQ IS THE POWER)
            int max = _array.Cast<int>().Max(); // (LINQ IS THE POWER)
            for (int j = 0; j < temp.Width; j++)
                for (int i = 0; i < temp.Height; i++)
                {
                    byte pix = (byte)(((double)_array[j, i] - min) / (double)(max - min) * 255.0); // (<--- тут) Узнали значение пиксела в диапазоне 0..255.
                    temp.SetPixel(j, i, Color.FromArgb(pix, pix, pix)); // (<--- тут) установили значение в GrayScale.
                }
            return temp;
        }
        // Метод визуализации загруженных файлов:
        private void RB_show_CheckedChanged(object sender, EventArgs e)
        {
            TrackBarKadr.Enabled = true;
            if (!(sender is TrackBar)) TrackBarKadr.Value = 1;
            TrackBarKadr_Scroll(sender, e);
            KadrNumber.Text = TrackBarKadr.Value.ToString();
            zoom.zoom = false;
            foreach (var chart in chartSTR.Series) chart.Points.Clear(); // (<--- тут) Очистили графики.
            foreach (var chart in chartSTB.Series) chart.Points.Clear(); // (<--- тут) Очистили графики.
            if (RB_temno_show.Checked)
            {
                TrackBarKadr.Maximum = GetKadrCount(temno_file);
                lbx_delKadr.Items.Clear();
                foreach (var item in deleteTemnoKadr)
                {
                    lbx_delKadr.Items.Add(item);
                }
                zoom.picture = temno_kadr;
                return;
            }
            if (RB_svet_clear_show.Checked || RB_svet_def_show.Checked || RB_svet_temno_show.Checked)
            {
                if (LIST_svet_files.SelectedIndex == -1)
                {
                    pictureBoxkadr.Image = pictureBoxkadr.BackgroundImage;
                    svet_kadr = null;
                    return;
                }
                lbx_delKadr.Items.Clear();
                foreach (var item in deleteKadr[LIST_svet_files.SelectedIndex])
                {
                    lbx_delKadr.Items.Add(item);
                }
                TrackBarKadr.Maximum = GetKadrCount(LIST_svet_files.SelectedItem as string);
                zoom.picture = svet_kadr;
                return;
            }
        }
        // Метод записи min и max и накапливание статистики:
        void MakeRep(int _x, int _y)
        {
            string rep = "";
            rep += $"Клик Х:{_x} Y:{_y}\r\nЗначения пиксел:\r\n";
            if (string.IsNullOrEmpty(temno_file)) rep += $"темновой пиксел:{temno_kadr[_x, _y]}\r\n";
            if (LIST_svet_files.SelectedIndex != -1) rep += $"световой пиксел:{svet_kadr[_x, _y]}\r\n";
            rep += $"Статистика\r\nmin\tmax\r\n";
            if (temno_kadr != null)
            {
                int minstr, minstb, maxstr, maxstb;
                minstr = (int)(chartSTR.Series["ChartTemnoSTR"].Points.Select(s => s.YValues.Min()).Min());
                maxstr = (int)(chartSTR.Series["ChartTemnoSTR"].Points.Select(s => s.YValues.Max()).Max());
                minstb = (int)(chartSTB.Series["ChartTemnoSTB"].Points.Select(s => s.XValue).Min());
                maxstb = (int)(chartSTB.Series["ChartTemnoSTB"].Points.Select(s => s.XValue).Max());
                rep += $"темн стр\r\n{minstr}\t{maxstr}\r\nтемн стб\r\n{minstb}\t{maxstb}\r\n";
            }
            if (svet_kadr != null)
            {
                int minstr, minstb, maxstr, maxstb;
                minstr = (int)(chartSTR.Series["ChartSvetSTR"].Points.Select(s => s.YValues.Min()).Min());
                maxstr = (int)(chartSTR.Series["ChartSvetSTR"].Points.Select(s => s.YValues.Max()).Max());
                minstb = (int)(chartSTB.Series["ChartSvetSTB"].Points.Select(s => s.XValue).Min());
                maxstb = (int)(chartSTB.Series["ChartSvetSTB"].Points.Select(s => s.XValue).Max());
                rep += $"свет стр\r\n{minstr}\t{maxstr}\r\nсвет стб\r\n{minstb}\t{maxstb}";
            }
            TB_Report.Text = rep;
        }

        #region picturebox
        // Метод отображения координат X и Y при визуализации загруженных файлов:
        private void pictureBoxkadr_MouseMove(object sender, MouseEventArgs e)
        {
            if (zoom.picture == null) return;
            int l = zoom.x1; int r = e.X; int t = zoom.y1; int b = e.Y;
            if (e.X < 0) r = 0;
            if (e.Y < 0) b = 0;
            if (e.X >= zoom.picture.GetLength(0)) r = zoom.picture.GetLength(0) - 1;
            if (e.Y >= zoom.picture.GetLength(1)) b = zoom.picture.GetLength(1) - 1;
            this.Text = String.Format("Строка {0} столбец {1} значение пиксела {2}", b + 1, r + 1, zoom.picture[r, b]);
            if (zoom.zoom == true)
            {
                try
                {
                    this.Text = String.Format("Строка {0} столбец {1} значение пиксела {2}",
                            Math.Round(zoom.zy1 + zoom.delta_y * b + 1, 2), Math.Round(zoom.zx1 + zoom.delta_x * r + 1, 2),
                            zoom.picture[(int)(zoom.zx1 + zoom.delta_x * r), (int)(zoom.zy1 + zoom.delta_y * b)]);
                }
                catch (IndexOutOfRangeException)
                {
                    this.Text = String.Format("Строка {0} столбец {1}",
                            Math.Round(zoom.zy1 + zoom.delta_y * b + 1, 2), Math.Round(zoom.zx1 + zoom.delta_x * r + 1, 2));
                }
            }
            if (e.Button == System.Windows.Forms.MouseButtons.Left && zoom.zoom == false)
            {
                pictureBoxkadr.Image = zoom.bitmap;
                Bitmap bb = new Bitmap(pictureBoxkadr.Image);
                pictureBoxkadr.Image = bb;
                Graphics graf = Graphics.FromImage(pictureBoxkadr.Image);
                if (l > r) { int x = l; l = r; r = x; }
                if (t > b) { int x = t; t = b; b = x; }
                if (l < 0) l = 0; if (r >= w) r = w - 1;
                if (t < 0) t = 0; if (b >= h) b = h - 1;
                using (Pen pen = new Pen(Color.Green))
                {
                    graf.DrawLine(pen, l, t, r, t);
                    graf.DrawLine(pen, r, t, r, b);
                    graf.DrawLine(pen, r, b, l, b);
                    graf.DrawLine(pen, l, b, l, t);
                }
                pictureBoxkadr.Invalidate();
            }
        }
        private void pictureBoxKadr_Click(object sender, EventArgs e)
        {

        }
        // Метод защиты от ненужного отображения координат X и Y при визуализации загруженных файлов:
        private void pictureBoxkadr_MouseLeave(object sender, EventArgs e)
        {
            this.Text = String.Format("Визуализатор и корректор: файл(ы) формата im2");
        }
        // Метод отображения координат X и Y при визуализации загруженных файлов:
        private void pictureBoxkadr_MouseUp(object sender, MouseEventArgs e)
        {
            if (temno_kadr == null && svet_kadr == null) return;
            if (temno_kadr == null) temno_kadr = svet_kadr;
            if (svet_kadr == null) svet_kadr = temno_kadr;
            zoom.x2 = e.X;
            zoom.y2 = e.Y;
            if (e.X < 0) zoom.x2 = 0;
            if (e.Y < 0) zoom.y2 = 0;
            if (e.X > w) zoom.x2 = w - 1;
            if (e.Y > h) zoom.y2 = h - 1;
            if ((zoom.x1 != zoom.x2 || zoom.y1 != zoom.y2) && zoom.zoom == false)
            {
                zoom.zoom = true;
                zooming_pixelisation();
                return;
            }
            if (zoom.zoom == false)
            {
                #region not zoom
                chartSTB.Series[0].Points.Clear();
                chartSTR.Series[0].Points.Clear();
                chartSTB.Series[1].Points.Clear();
                chartSTR.Series[1].Points.Clear();
                zoom.xmin = 16000;
                zoom.xmax = 0;
                zoom.ymin = 16000;
                zoom.ymax = 0;
                for (int i = 0; i < h; i++)
                {
                    chartSTB.Series[0].Points.AddXY(svet_kadr[zoom.x2, i], h - i);
                    chartSTB.Series[1].Points.AddXY(temno_kadr[zoom.x2, i], h - i);
                    if (zoom.ymin > zoom.picture[zoom.x2, i]) zoom.ymin = zoom.picture[zoom.x2, i];
                    if (zoom.ymax < zoom.picture[zoom.x2, i]) zoom.ymax = zoom.picture[zoom.x2, i];
                }
                for (int i = 0; i < w; i++)
                {
                    chartSTR.Series[0].Points.AddXY(i + 1, svet_kadr[i, zoom.y2]);
                    chartSTR.Series[1].Points.AddXY(i + 1, temno_kadr[i, zoom.y2]);
                    if (zoom.xmin > zoom.picture[i, zoom.y2]) zoom.xmin = zoom.picture[i, zoom.y2];
                    if (zoom.xmax < zoom.picture[i, zoom.y2]) zoom.xmax = zoom.picture[i, zoom.y2];
                }
                chartSTB.ChartAreas[0].AxisY.Minimum = 0;
                chartSTB.ChartAreas[0].AxisY.Maximum = h;
                chartSTB.ChartAreas[0].AxisX.Minimum = 0;
                chartSTB.ChartAreas[0].AxisX.Maximum = zoom.ymax;
                chartSTR.ChartAreas[0].AxisY.Minimum = zoom.xmin;
                chartSTR.ChartAreas[0].AxisY.Maximum = zoom.xmax;
                chartSTR.ChartAreas[0].AxisX.Minimum = 0;
                chartSTR.ChartAreas[0].AxisX.Maximum = w;
                this.Text = String.Format("X={0}, Y={1} значение={2}", zoom.x2 + 1, zoom.y2 + 1, zoom.picture[zoom.x2, zoom.y2]);
                MakeRep(zoom.x2 + 1, zoom.y2 + 1);
                #endregion
            }
            else
            {
                #region zoom
                int zxmin = 16000;
                int zxmax = 0;
                int zymin = 16000;
                int zymax = 0;
                zoom.zx = (double)zoom.zx1 + zoom.delta_x * zoom.x2;
                zoom.zy = (double)zoom.zy1 + zoom.delta_y * zoom.y2;
                try
                {
                    chartSTB.Series[0].Points.Clear();
                    chartSTR.Series[0].Points.Clear();
                    chartSTB.Series[1].Points.Clear();
                    chartSTR.Series[1].Points.Clear();
                    for (int i = zoom.zy1; i < zoom.zy2; i++)
                    {
                        chartSTB.Series[0].Points.AddXY(temno_kadr[(int)zoom.zx, i], zoom.zy2 - (i - zoom.zy1));
                        chartSTB.Series[1].Points.AddXY(svet_kadr[(int)zoom.zx, i], zoom.zy2 - (i - zoom.zy1));
                        //if (zymin > kadrSvet[(int)zoom.zx, i]) zymin = kadrSvet[(int)zoom.zx, i];
                        if (zymin > temno_kadr[(int)zoom.zx, i]) zymin = temno_kadr[(int)zoom.zx, i];
                        if (zymax < svet_kadr[(int)zoom.zx, i]) zymax = svet_kadr[(int)zoom.zx, i];
                    }
                    for (int i = zoom.zx1; i < zoom.zx2; i++)
                    {
                        chartSTR.Series[0].Points.AddXY(i, temno_kadr[i, (int)zoom.zy]);
                        chartSTR.Series[1].Points.AddXY(i, svet_kadr[i, (int)zoom.zy]);
                        //if (zxmin > kadrSvet[i, (int)zoom.zy]) zxmin = kadrSvet[i, (int)zoom.zy];
                        if (zxmin > temno_kadr[i, (int)zoom.zy]) zxmin = temno_kadr[i, (int)zoom.zy];
                        if (zxmax < svet_kadr[i, (int)zoom.zy]) zxmax = svet_kadr[i, (int)zoom.zy];
                    }
                    chartSTB.ChartAreas[0].AxisY.Minimum = zoom.zy1;
                    chartSTB.ChartAreas[0].AxisY.Maximum = zoom.zy2 + 1;
                    chartSTB.ChartAreas[0].AxisX.Minimum = zymin;
                    chartSTB.ChartAreas[0].AxisX.Maximum = zymax;
                    chartSTR.ChartAreas[0].AxisY.Minimum = zxmin;
                    chartSTR.ChartAreas[0].AxisY.Maximum = zxmax;
                    chartSTR.ChartAreas[0].AxisX.Minimum = zoom.zx1;
                    chartSTR.ChartAreas[0].AxisX.Maximum = zoom.zx2 + 1;
                    this.Text = String.Format("X={0}, Y={1} значение={2}", Math.Round(zoom.zx + 1, 2), Math.Round(zoom.zy + 1, 2), zoom.picture[(int)zoom.zx, (int)zoom.zy]);
                    MakeRep((int)Math.Round(zoom.zx + 1, 2), (int)Math.Round(zoom.zy + 1, 2));
                }
                catch (Exception)
                {
                    this.Text = "Курсор за границей кадра";
                }
                //pictureBoxKadr.Image = bitmap;
                #endregion
            }
        }
        private void pictureBoxKadr_MouseDown(object sender, MouseEventArgs e)
        {
            zoom.x1 = e.X;
            zoom.y1 = e.Y;
        }
        #endregion

        #region Nishtiaki
        /* Различные 
         *      ништяки и кнопки!
         */
        private void btn_MouseHover(object sender, EventArgs e)
        {
            (sender as Button).BackColor = Color.Green;
        }
        private void btn_MouseLeave(object sender, EventArgs e)
        {
            (sender as Button).BackColor = Color.Gainsboro;
        }
        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }
        private void удалитьФайлToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (LIST_svet_files.SelectedIndex == -1) return;
            LIST_svet_files.Items.Remove(LIST_svet_files.SelectedItem);
        }
        private void снятьВыделениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LIST_svet_files.SelectedIndex = -1;
        }
        private void TrackBarKadr_Scroll(object sender, EventArgs e)
        {
            if (RB_temno_show.Checked)
            {
                pictureBoxkadr.Image = temno_kadr != null ? ConvertArrayToBtm(LoadKadr(temno_file, TrackBarKadr.Value, false, true)) : pictureBoxkadr.BackgroundImage;

                zoom.bitmap = pictureBoxkadr.Image as Bitmap;
                return;
            }
            if (RB_svet_clear_show.Checked)
            {
                if (LIST_svet_files.SelectedIndex == -1)
                {
                    pictureBoxkadr.Image = pictureBoxkadr.BackgroundImage;
                    svet_kadr = null;
                    return;
                }
                svet_kadr = LoadKadr(LIST_svet_files.SelectedItem as string, TrackBarKadr.Value);
                pictureBoxkadr.Image = ConvertArrayToBtm(svet_kadr);
            }
            if (RB_svet_temno_show.Checked)
            {
                if (LIST_svet_files.SelectedIndex == -1)
                {
                    pictureBoxkadr.Image = pictureBoxkadr.BackgroundImage;
                    svet_kadr = null;
                    return;
                }
                svet_kadr = LoadKadr(LIST_svet_files.SelectedItem as string, TrackBarKadr.Value, true, true);
                pictureBoxkadr.Image = ConvertArrayToBtm(svet_kadr);
            }
            if (RB_svet_def_show.Checked)
            {
                if (LIST_svet_files.SelectedIndex == -1)
                {
                    pictureBoxkadr.Image = pictureBoxkadr.BackgroundImage;
                    svet_kadr = null;
                    return;
                }
                svet_kadr = LoadKadr(LIST_svet_files.SelectedItem as string, TrackBarKadr.Value, false, true);
                pictureBoxkadr.Image = ConvertArrayToBtm(svet_kadr);
            }
            zoom.bitmap = pictureBoxkadr.Image as Bitmap;
        }
        private void LIST_svet_files_MouseClick(object sender, MouseEventArgs e)
        {

        }
        private void lbx_delKadr_MouseClick(object sender, MouseEventArgs e)
        {

        }
        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int pointer = LIST_svet_files.SelectedIndex;
            LIST_svet_files.Items.RemoveAt(pointer);
            deleteKadr.RemoveAt(pointer);
        }
        #endregion

        #region zoom
        /* ЗУУУУУУУМ 
         *      ЭФФЕЕЕЕЕЕЕКТ!
         */
        public class ForZoom
        {
            public int[,] picture;
            public Bitmap bitmap;
            public int x1, y1, x2, y2; //координаты точек, точка клика в масштабе, и цена пиксела в масштабе
            public int zx1, zx2, zy1, zy2;
            public double zx, zy;// границы зума, курсора в зуме
            public double delta_x, delta_y;
            public int xmin, xmax, ymin, ymax; //значения границ для графиков
            public bool zoom;
        }
        private void pictureBoxKadr_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                zoom.zoom = false;
                pictureBoxkadr.Image = zoom.bitmap;
                pictureBoxkadr.SizeMode = PictureBoxSizeMode.AutoSize;
                this.Text = String.Format("X={0}, Y={1} значение={2}", e.X + 1, e.Y + 1, zoom.picture[e.X, e.Y]);
            }
        }
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            lbx_delKadr.SelectedIndex = -1;
        }
        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            int pointer = lbx_delKadr.SelectedIndex;
            lbx_delKadr.Items.RemoveAt(pointer);
            if (RB_temno_show.Checked) deleteTemnoKadr.RemoveAt(pointer);
            else deleteKadr[LIST_svet_files.SelectedIndex].RemoveAt(pointer);
        }

        private void TrackBarKadr_Scroll_1(object sender, EventArgs e)
        {
            RB_show_CheckedChanged(sender, e);
        }

        private void zooming_pixelisation()
        {
            if (zoom.x1 > zoom.x2) { int x = zoom.x1; zoom.x1 = zoom.x2; zoom.x2 = x; }
            if (zoom.y1 > zoom.y2) { int y = zoom.y1; zoom.y1 = zoom.y2; zoom.y2 = y; }
            zoom.zx1 = zoom.x1; zoom.zx2 = zoom.x2; zoom.zy1 = zoom.y1; zoom.zy2 = zoom.y2;
            zoom.delta_x = (double)(zoom.zx2 - zoom.zx1 + 1) / (double)w;
            zoom.delta_y = (double)(zoom.zy2 - zoom.zy1 + 1) / (double)h;
            using (Bitmap zoombitmap = new Bitmap(w, h, System.Drawing.Imaging.PixelFormat.Format24bppRgb))
            {
                double pos_x = zoom.zx1;
                for (int x = 0; x < w; x++)
                {
                    if (pos_x >= w) break;
                    double pos_y = zoom.zy1;
                    for (int y = 0; y < h; y++)
                    {
                        if (pos_y >= h) break;
                        zoombitmap.SetPixel(x, y, zoom.bitmap.GetPixel((int)pos_x, (int)pos_y));
                        pos_y += zoom.delta_y;
                    }
                    pos_x += zoom.delta_x;
                }
                pictureBoxkadr.Image = (Image)zoombitmap.Clone();
            }
        }
        #endregion
    }
}
