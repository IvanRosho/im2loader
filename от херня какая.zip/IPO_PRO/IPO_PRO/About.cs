﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Windows.Forms;

namespace IPO_PRO
{
    public partial class About : Form
    {
        Form1 form;
        public About(Form1 f)
        {
            InitializeComponent();
            form = f;
            this.Text = String.Format("Title {0}", AssemblyTitle);
            this.labelProductName.Text = AssemblyProduct;
            this.labelVersion.Text = "Version 1.1";
            this.labelCopyright.Text = AssemblyCopyright;
            this.labelCompanyName.Text = AssemblyCompany;
            this.textBoxDescription.Text = "Описание: \r\n" +
            "     Специализированное програмное обеспечение визуализации " +
            "файлов ВИ, отображения служебной информации и предварительной " +
            "обработки файлов ВИ с целью их дальнейшего использования " +
            "в качестве входных данных в ИПО-АК, ИПО-ДФ, ИПО-К. \r\n \r\n" +
            "Обеспечивается выполнение следующих функций: \r\n" +
            "   - визуализация на экране монитора файлов ВИ; \r\n" +
            "   - работа с изображением (изменение масштаба, построение графиков " +
            "сигнала для выбранной строки и/или столбца, отображение координат " +
            "текущего положения курсора и уровня сигнала с элемента под курсором); \r\n" +
            "   - отображение служебной информации из состава метаданных; \r\n" +
            "   - расчет массива ККТС, его сохранение и визуализация как файла ВИ; \r\n" +
            "   - предварительная обработка ВИ (коррекция с использованием " +
            "массива ККТС, коррекция сигнала с  дефектных элементов, " +
            "усреднение по кадрам и создание нового файла ВИ).";
            this.labelAvtors.Text = "Белокуров Е.А. (инженер-исследователь 3 категории)";
        }

        public string AssemblyTitle
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                if (attributes.Length > 0)
                {
                    AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                    if (titleAttribute.Title != "")
                    {
                        return titleAttribute.Title;
                    }
                }
                return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
            }
        }

        public string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        public string AssemblyDescription
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyDescriptionAttribute)attributes[0]).Description;
            }
        }

        public string AssemblyProduct
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyProductAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyProductAttribute)attributes[0]).Product;
            }
        }

        public string AssemblyCopyright
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
            }
        }

        public string AssemblyCompany
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCompanyAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCompanyAttribute)attributes[0]).Company;
            }
        }

        private void OK_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void About_FormClosing(object sender, FormClosingEventArgs e)
        {
            form.closeabout();
        }
    }
}
